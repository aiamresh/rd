export interface Room {
  id: string;
  name: string;
  tagline: string;
  description: string;
  image: string;
  price: number;
  size: string; // e.g. "320 sq. ft."
  capacity: string; // e.g. "2 Adults + 1 Child"
  bedType: string; // e.g. "King Size Bed"
  view: string; // e.g. "Temple View" or "City View"
  amenities: string[];
  images?: string[];
  tags?: string[];
  stars?: number;
}

export interface Testimonial {
  id: string;
  name: string;
  location: string;
  rating: number;
  date: string;
  review: string;
}

export interface GalleryItem {
  id: string;
  category: 'rooms' | 'dining' | 'exterior' | 'spiritual';
  title: string;
  image: string;
}

export interface BookingDetails {
  checkIn: string;
  checkOut: string;
  guests: number;
  roomType: string;
  name: string;
  email: string;
  phone: string;
  specialRequests?: string;
}
