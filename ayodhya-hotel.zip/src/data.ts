import { Room, Testimonial, GalleryItem } from './types';

export const HOTEL_INFO = {
  name: 'Hotel Raj Darbar Ayodhya',
  tagline: 'Luxury, Peace and Royal Hospitality near Ayodhya Dham Railway Station',
  shortName: 'Hotel Raj Darbar',
  phone1: '+91 95191 02222',
  phone2: '+91 73093 42222',
  phone3: '+91 95191 02222',
  email: 'info@hotelrajdarbarayodhya.com',
  address: 'Behind Multi Level Parking, Near Ayodhya Dham Railway Station, Ayodhya, Uttar Pradesh - 224123',
  mapIframeUrl: 'https://maps.google.com/maps?q=Hotel%20Raj%20Darbar%20Ayodhya%20Behind%20Multi%20Level%20Parking&t=&z=15&ie=UTF8&iwloc=&output=embed',
};

export const ROOMS: Room[] = [
  {
    id: 'executive',
    name: 'Executive Room',
    tagline: 'Ideal for business and leisure travelers seeking modern luxury.',
    description: 'Our Executive Rooms offer the perfect blend of comfort and functionality. Ideal for business and leisure travelers alike, with state-of-the-art facilities.',
    image: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&q=80&w=800',
    images: [
      'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1591088398332-8a7791972843?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&q=80&w=800'
    ],
    price: 8500,
    size: '450 sqft',
    capacity: '2',
    bedType: 'King Size Bed',
    view: 'City View',
    stars: 5,
    tags: ['City View', 'Business Friendly', 'Modern Design'],
    amenities: [
      'High-Speed Wi-Fi',
      'Air Conditioning',
      'Flat-Screen LED TV',
      'Tea & Coffee Maker',
      '24/7 Room Service',
      'In-Room Electronic Safe',
      'Premium Toiletries',
      'Daily Mineral Water'
    ]
  },
  {
    id: 'superior',
    name: 'Superior Room',
    tagline: 'Refined styling with premium upgrades and generous space.',
    description: 'Spacious rooms with premium furnishings and enhanced amenities for the discerning traveler who appreciates extra comfort and fine service.',
    image: 'https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&q=80&w=800',
    images: [
      'https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1591088398332-8a7791972843?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&q=80&w=800'
    ],
    price: 12000,
    size: '550 sqft',
    capacity: '2',
    bedType: 'Queen Size Double Bed',
    view: 'Spiritual Temple View',
    stars: 5,
    tags: ['Extra Space', 'Premium Bedding', 'Lounge Area'],
    amenities: [
      'High-Speed Wi-Fi',
      'Air Conditioning',
      '43" Smart LED TV',
      'Premium Tea & Coffee Kit',
      'Minibar (Soft Drinks)',
      'Plush Bathrobes & Slippers',
      'Iron & Ironing Board',
      '24/7 In-Room Dining'
    ]
  },
  {
    id: 'signature',
    name: 'Signature Suites',
    tagline: 'Luxurious design with separate living area and tailored service.',
    description: 'Luxurious suites with separate living area, premium amenities, and personalized service for an unmatched living experience.',
    image: 'https://images.unsplash.com/photo-1591088398332-8a7791972843?auto=format&fit=crop&q=80&w=800',
    images: [
      'https://images.unsplash.com/photo-1591088398332-8a7791972843?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1517840901100-8179e982acb7?auto=format&fit=crop&q=80&w=800'
    ],
    price: 18000,
    size: '750 sqft',
    capacity: '3',
    bedType: 'Orthopedic King Bed',
    view: 'Ram Janmabhoomi Skyline View',
    stars: 5,
    tags: ['Living Room', 'Luxury Experience', 'Personalized Service'],
    amenities: [
      'Panoramic French Windows',
      'Complimentary High-Speed Wi-Fi',
      '50" Smart TV with Streaming',
      'Bespoke Fruit Basket on Arrival',
      'Premium Coffee Press',
      'Luxury Walk-in Shower',
      'Daily Temple Prasad',
      'Dedicated Travel Desk Assistance'
    ]
  },
  {
    id: 'presidential',
    name: 'Presidential Suites',
    tagline: 'The ultimate pinnacle of grand luxury and absolute peace.',
    description: 'The ultimate in luxury with multiple bedrooms, state-of-the-art facilities, and dedicated concierge services at your beck and call.',
    image: 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&q=80&w=800',
    images: [
      'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1591088398332-8a7791972843?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1517840901100-8179e982acb7?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1445019980597-93fa8acb246c?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1495365200479-c4ed1d35e1aa?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1496417263034-38ec4f0b665a?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1493809842364-78817add7ffb?auto=format&fit=crop&q=80&w=800'
    ],
    price: 25000,
    size: '1200 sqft',
    capacity: '4',
    bedType: 'Super King Royal Bed',
    view: 'Unobstructed Ram Mandir & Sarayu River View',
    stars: 5,
    tags: ['Multiple Bedrooms', 'Personal Butler', 'Ultimate Luxury'],
    amenities: [
      'Unobstructed Ram Mandir Views',
      'Private Dining & Office Lounge',
      'Luxury Bathtub with Jacuzzi Jets',
      'Personal Butler Service',
      'Complimentary Airport/Station Pick-Up',
      'Premium Ayurvedic Spa Toiletries',
      'Morning Spiritual Yoga Session',
      'Premium Soundbar System'
    ]
  },
  {
    id: 'family',
    name: 'Family Suites',
    tagline: 'Ideal for families seeking a shared premium travel experience.',
    description: 'Perfect for families, these spacious suites offer multiple bedrooms and family-friendly amenities.',
    image: 'https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&q=80&w=800',
    images: [
      'https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1591088398332-8a7791972843?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1517840901100-8179e982acb7?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1445019980597-93fa8acb246c?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1495365200479-c4ed1d35e1aa?auto=format&fit=crop&q=80&w=800'
    ],
    price: 16000,
    size: '850 sqft',
    capacity: '5',
    bedType: '1 King Bed + 1 Queen Bed',
    view: 'Scenic Temple Garden View',
    stars: 5,
    tags: ['Multiple Bedrooms', 'Family Friendly', 'Kids Entertainment'],
    amenities: [
      'Two Interconnected Bedrooms',
      'Separate Living & Lounge Area',
      'Two Full Luxury Bathrooms',
      'Complimentary High-Speed Wi-Fi',
      'Dual 43" Smart TVs',
      'Welcome Drink & Sweets',
      'Express Laundry Service',
      'VIP Temple Darshan Concierge'
    ]
  }
];

export const AMENITIES = [
  {
    title: 'Pure Vegetarian Cuisine',
    desc: '100% pure vegetarian multi-cuisine restaurant serving authentic satvik and traditional recipes.',
    icon: 'UtensilsCrossed'
  },
  {
    title: 'Divine Temple Tours',
    desc: 'Dedicated concierge helping plan fast-track Darshan, Sarayu Aarti, and guided spiritual journeys.',
    icon: 'Compass'
  },
  {
    title: '24/7 Room Service',
    desc: 'Bespoke hospitality and dining served straight to your sanctuary at any hour of the day.',
    icon: 'Clock'
  },
  {
    title: 'High-Speed Wi-Fi',
    desc: 'Stay connected with your global friends and family with seamless high-speed internet access.',
    icon: 'Wifi'
  },
  {
    title: 'Free Valet Parking',
    desc: 'Secure, ample, and monitored parking spaces with valet facilities for all our esteemed guests.',
    icon: 'Car'
  },
  {
    title: 'Spacious Banqueting',
    desc: 'Elegant indoor and outdoor spaces designed perfectly for holy events, weddings, and celebrations.',
    icon: 'Award'
  },
  {
    title: 'Airport & Railway Pickups',
    desc: 'Seamless premium transfer service from Ayodhya Airport, Lucknow Airport, or Ayodhya Dham Junction.',
    icon: 'Plane'
  },
  {
    title: 'Daily Yoga & Meditation',
    desc: 'Renew your spirit with curated morning sessions led by local experts on our scenic rooftop terrace.',
    icon: 'Sparkles'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 't1',
    name: 'Rajesh K. Sharma',
    location: 'Mumbai, India',
    rating: 5,
    date: 'June 2026',
    review: 'Hotel Raj Darbar made our family pilgrimage absolutely magical. It is ideally located behind the multi-level parking and near the railway station, which allowed us to visit the Ram Mandir comfortably. The staff is extremely polite, and the pure vegetarian restaurant is exceptional. Highly recommend!'
  },
  {
    id: 't2',
    name: 'Dr. Meera Vasudevan',
    location: 'Chennai, India',
    rating: 5,
    date: 'July 2026',
    review: 'An oasis of tranquility in a crowded sacred city. The rooms are spotless, modern, and beautifully decorated with royal style. The travel desk helped arrange our local Darshan and guide. It exceeded all our expectations of luxury and comfort.'
  },
  {
    id: 't3',
    name: 'Amit and Sneha Patel',
    location: 'London, UK',
    rating: 5,
    date: 'May 2026',
    review: 'Coming from abroad, we were looking for clean, premium standard hospitality combined with divine vibes. Hotel Raj Darbar delivered perfectly. The La\'Pulse Dine dining was scrumptious, the suite was majestic, and the prompt hospitality was unforgettable.'
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'g1',
    category: 'exterior',
    title: 'Grand Hotel Entrance & Façade',
    image: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'g2',
    category: 'rooms',
    title: 'Hotel Raj Darbar Suite Master Bedroom',
    image: 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'g3',
    category: 'dining',
    title: 'Naivedyam Fine Dining Ambience',
    image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'g4',
    category: 'spiritual',
    title: 'Serene Sarayu River Sunset & Aarti Ghats',
    image: 'https://images.unsplash.com/photo-1608958416757-cfbbf3192348?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'g5',
    category: 'rooms',
    title: 'Executive Heritage Suite Comfort',
    image: 'https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'g6',
    category: 'dining',
    title: 'Bespoke Satvik Delicacies Served in Copperware',
    image: 'https://images.unsplash.com/photo-1601050690597-df056fb4ce78?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'g7',
    category: 'exterior',
    title: 'Warm Lobby Welcome Lounge',
    image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'g8',
    category: 'spiritual',
    title: 'Majestic Heritage Pillars & Architecture',
    image: 'https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&q=80&w=800'
  }
];
