import React, { useState } from 'react';
import { 
  Check, 
  ArrowRight, 
  Utensils, 
  Clock, 
  Sparkles, 
  Users, 
  Wine, 
  Coffee, 
  Calendar, 
  Phone, 
  Award, 
  Heart,
  X,
  MapPin,
  Flame,
  Send
} from 'lucide-react';

interface DiningPageProps {
  onBackToHome?: () => void;
}

interface MenuItem {
  name: string;
  price: string;
}

interface MenuCategory {
  title: string;
  emoji: string;
  items: MenuItem[];
}

export default function DiningPage({ onBackToHome }: DiningPageProps) {
  // Modal States
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [bookingStep, setBookingStep] = useState<'form' | 'success'>('form');
  const [mealPreference, setMealPreference] = useState<'breakfast' | 'dinner' | 'general'>('general');
  
  // Form State
  const [reservationForm, setReservationForm] = useState({
    name: '',
    email: '',
    phone: '',
    date: new Date().toISOString().split('T')[0],
    time: '19:30',
    guests: '4',
    occasion: 'Casual Dining',
    specialRequests: ''
  });

  const [confirmedReservationDetails, setConfirmedReservationDetails] = useState<any>(null);

  const openReservationModal = (pref: 'breakfast' | 'dinner' | 'general' = 'general') => {
    setMealPreference(pref);
    if (pref === 'breakfast') {
      setReservationForm(prev => ({ ...prev, time: '09:00', occasion: 'Breakfast Meeting' }));
    } else if (pref === 'dinner') {
      setReservationForm(prev => ({ ...prev, time: '20:00', occasion: 'Anniversary' }));
    }
    setIsModalOpen(true);
    setBookingStep('form');
  };

  const handleReservationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const details = {
      reservationId: 'RES-LAP-' + Math.floor(100000 + Math.random() * 900000),
      ...reservationForm,
      mealPreference
    };

    setConfirmedReservationDetails(details);
    setBookingStep('success');
  };

  // Menu Categories with items matching screenshots exactly
  const menuCategories: MenuCategory[] = [
    {
      title: "Indian Starters",
      emoji: "🥒",
      items: [
        { name: "Samosa", price: "225/-" },
        { name: "Pakora Mixed", price: "245/-" },
        { name: "Paneer Tikka", price: "295/-" },
        { name: "Malai Seekh Kabab (Veg)", price: "315/-" },
        { name: "Vegetable Cutlet", price: "225/-" },
        { name: "Hara Bhara Kabab", price: "275/-" }
      ]
    },
    {
      title: "Main Courses",
      emoji: "🍲",
      items: [
        { name: "Paneer Makhani", price: "325/-" },
        { name: "Vegetable Biryani", price: "275/-" },
        { name: "Masala Dosa", price: "280/-" },
        { name: "Chole Bhature", price: "245/-" },
        { name: "Paneer Tikka Masala", price: "335/-" },
        { name: "Mixed Vegetable Curry", price: "250/-" }
      ]
    },
    {
      title: "Bread & Rice",
      emoji: "🍞",
      items: [
        { name: "Naan", price: "45/-" },
        { name: "Garlic Naan", price: "55/-" },
        { name: "Tandoori Roti", price: "40/-" },
        { name: "Basmati Rice", price: "60/-" },
        { name: "Vegetable Pulao", price: "75/-" },
        { name: "Butter Naan", price: "50/-" }
      ]
    },
    {
      title: "Desserts",
      emoji: "🍰",
      items: [
        { name: "Gulab Jamun", price: "120/-" },
        { name: "Kheer", price: "100/-" },
        { name: "Chocolate Lava Cake", price: "180/-" },
        { name: "Mango Sorbet", price: "90/-" },
        { name: "Rasmalai", price: "140/-" },
        { name: "Ice Cream Assorted", price: "120/-" }
      ]
    },
    {
      title: "Refreshing Beverages",
      emoji: "🍹",
      items: [
        { name: "Aerated Beverages (Cola, Sprite etc)", price: "125/-" },
        { name: "Masala Cold Drinks", price: "130/-" },
        { name: "Seasonal Fresh Fruit Juice", price: "170/-" },
        { name: "Choice of Canned Juices", price: "150/-" },
        { name: "Fresh Lime Soda", price: "125/-" },
        { name: "Iced Tea (Lemon / Mint)", price: "125/-" }
      ]
    },
    {
      title: "Premium Beverages",
      emoji: "☕",
      items: [
        { name: "Lassi (Sweet / Salted)", price: "150/-" },
        { name: "Choice of Flavored Lassi", price: "180/-" },
        { name: "Choice of Milk Shake", price: "180/-" },
        { name: "Kit Kat Shake", price: "200/-" },
        { name: "Cold Coffee", price: "180/-" },
        { name: "Cold Coffee with Ice Cream", price: "200/-" }
      ]
    },
    {
      title: "Special Beverages",
      emoji: "🌿",
      items: [
        { name: "Energy Drink (Red Bull)", price: "250/-" },
        { name: "Butter Milk", price: "125/-" },
        { name: "Fresh Lime Water", price: "125/-" },
        { name: "Package Drinking Water", price: "60/-" },
        { name: "Jal Jeera", price: "90/-" },
        { name: "Shikanji", price: "90/-" }
      ]
    },
    {
      title: "Breakfast & Brunch",
      emoji: "🥐",
      items: [
        { name: "Aloo Paratha", price: "200/-" },
        { name: "Cheese Paratha", price: "225/-" },
        { name: "Paneer Paratha", price: "250/-" },
        { name: "Chole Bhature", price: "245/-" },
        { name: "Poori Bhaji", price: "225/-" },
        { name: "French Toast", price: "200/-" }
      ]
    }
  ];

  return (
    <div className="bg-[#FAF9F5] min-h-screen font-sans text-stone-800">
      
      {/* 1. Header Banner - Dark Elegant Theme matching the screenshot */}
      <div className="bg-neutral-900 pt-32 pb-20 px-4 text-center border-b border-amber-900/20">
        <div className="max-w-4xl mx-auto space-y-4">
          <span className="text-amber-400 font-bold uppercase tracking-[0.2em] text-xs sm:text-sm">
            ✨ Culinary Artistry At Hotel Raj Darbar
          </span>
          <h1 className="font-display font-extrabold text-white text-4xl sm:text-5xl md:text-6xl uppercase tracking-tight">
            La'Pulse Dine
          </h1>
          <p className="text-stone-300 text-sm sm:text-base md:text-lg font-light tracking-wide max-w-2xl mx-auto">
            Fine Dining Excellence & Culinary Artistry
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
        
        {/* 2. Primary Feature Card: Culinary Excellence Box */}
        <div className="bg-amber-50/40 rounded-[2rem] border border-amber-200/50 p-6 sm:p-10 md:p-12 shadow-md" id="culinary-excellence-hero">
          <div className="flex flex-col items-center text-center space-y-4 mb-8">
            <div className="w-16 h-16 rounded-full bg-amber-100 flex items-center justify-center text-amber-800">
              <Utensils size={32} />
            </div>
            <span className="text-stone-500 font-mono text-xs uppercase tracking-widest">
              Culinary Excellence
            </span>
            <h2 className="font-display font-extrabold text-3xl sm:text-4xl text-stone-900 uppercase tracking-tight">
              La'Pulse Dine
            </h2>
            <p className="text-stone-600 text-sm sm:text-base italic max-w-xl">
              Where tradition meets innovation in every exquisite dish
            </p>
            
            {/* Spec badging */}
            <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-6 pt-3 text-stone-700 text-xs sm:text-sm font-semibold uppercase tracking-wider">
              <span className="flex items-center space-x-1">
                <span>⭐</span>
                <span>5-Star Dining</span>
              </span>
              <span className="text-amber-300 hidden sm:inline">•</span>
              <span className="flex items-center space-x-1">
                <span>🕒</span>
                <span>Open 6 AM - 11 PM</span>
              </span>
              <span className="text-amber-300 hidden sm:inline">•</span>
              <span className="flex items-center space-x-1">
                <span>👥</span>
                <span>Capacity: 150</span>
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 pt-6 border-t border-amber-200/30">
            {/* Left Col: Text */}
            <div className="lg:col-span-7 space-y-6 flex flex-col justify-center">
              <h3 className="font-display font-bold text-stone-900 text-2xl uppercase tracking-wider">
                About La'Pulse Dine
              </h3>
              <p className="text-stone-650 text-sm sm:text-base leading-relaxed">
                La'Pulse Dine represents the pinnacle of fine dining at Hotel Raj Darbar. Our award-winning culinary team crafts exceptional dishes that celebrate both traditional Indian flavors and contemporary international cuisine.
              </p>
              <p className="text-stone-650 text-sm sm:text-base leading-relaxed">
                Every dish is a masterpiece, prepared with the finest ingredients sourced locally and internationally. We believe in creating not just meals, but memorable experiences that delight all your senses.
              </p>

              {/* Checklist */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2">
                <div className="flex items-center space-x-2.5">
                  <div className="w-5 h-5 rounded-full bg-amber-100 flex items-center justify-center text-amber-800 shrink-0">
                    <Check size={12} strokeWidth={3} />
                  </div>
                  <span className="text-stone-800 font-medium text-xs sm:text-sm">Award-Winning Chef</span>
                </div>
                <div className="flex items-center space-x-2.5">
                  <div className="w-5 h-5 rounded-full bg-amber-100 flex items-center justify-center text-amber-800 shrink-0">
                    <Check size={12} strokeWidth={3} />
                  </div>
                  <span className="text-stone-800 font-medium text-xs sm:text-sm">Premium Ingredients</span>
                </div>
                <div className="flex items-center space-x-2.5">
                  <div className="w-5 h-5 rounded-full bg-amber-100 flex items-center justify-center text-amber-800 shrink-0">
                    <Check size={12} strokeWidth={3} />
                  </div>
                  <span className="text-stone-800 font-medium text-xs sm:text-sm">Elegant Ambiance</span>
                </div>
                <div className="flex items-center space-x-2.5">
                  <div className="w-5 h-5 rounded-full bg-amber-100 flex items-center justify-center text-amber-800 shrink-0">
                    <Check size={12} strokeWidth={3} />
                  </div>
                  <span className="text-stone-800 font-medium text-xs sm:text-sm">Professional Service</span>
                </div>
              </div>
            </div>

            {/* Right Col: Image block */}
            <div className="lg:col-span-5 relative h-64 sm:h-80 md:h-96 rounded-2xl overflow-hidden shadow-lg border border-amber-250/20">
              <img 
                src="https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80&w=800" 
                alt="Fine Dining Experience"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-transparent"></div>
              <div className="absolute bottom-6 left-6 text-white space-y-1">
                <span className="bg-amber-500 text-stone-950 text-[10px] uppercase font-bold px-2 py-0.5 rounded">Fine Dining Experience</span>
                <p className="text-stone-200 text-xs">Exquisite table arrangement and luxury settings</p>
              </div>
            </div>
          </div>
        </div>

        {/* 3. Pure Veg Banner */}
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-5 text-center flex flex-col sm:flex-row items-center justify-center gap-3 shadow-sm">
          <span className="text-2xl">🌱</span>
          <div>
            <h4 className="font-display font-extrabold text-emerald-800 uppercase tracking-wider text-base sm:text-lg">
              100% Pure Vegetarian
            </h4>
            <p className="text-emerald-700 text-xs sm:text-sm mt-0.5">
              At La'Pulse Dine, we celebrate the richness of vegetarian cuisine with innovative recipes and premium ingredients.
            </p>
          </div>
          <span className="text-2xl hidden sm:inline">🌱</span>
        </div>

        {/* 4. Three Pillars of Service */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          <div className="bg-white border border-stone-200/80 rounded-2xl p-6 shadow-sm text-center space-y-4 hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-full bg-amber-50 flex items-center justify-center text-amber-700 mx-auto">
              <Utensils size={22} />
            </div>
            <h4 className="font-display font-bold text-stone-900 text-base uppercase tracking-wider">
              Fine Dining
            </h4>
            <p className="text-stone-500 text-xs sm:text-sm leading-relaxed">
              Indulge in impeccably presented dishes in our elegant dining room with sophisticated décor.
            </p>
          </div>

          <div className="bg-white border border-stone-200/80 rounded-2xl p-6 shadow-sm text-center space-y-4 hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-full bg-amber-50 flex items-center justify-center text-amber-700 mx-auto">
              <Wine size={22} />
            </div>
            <h4 className="font-display font-bold text-stone-900 text-base uppercase tracking-wider">
              Wine Selection
            </h4>
            <p className="text-stone-500 text-xs sm:text-sm leading-relaxed">
              Curated mocktails and non-alcoholic premium sparkling grape juices to complement your meal.
            </p>
          </div>

          <div className="bg-white border border-stone-200/80 rounded-2xl p-6 shadow-sm text-center space-y-4 hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-full bg-amber-50 flex items-center justify-center text-amber-700 mx-auto">
              <Clock size={22} />
            </div>
            <h4 className="font-display font-bold text-stone-900 text-base uppercase tracking-wider">
              Room Service
            </h4>
            <p className="text-stone-500 text-xs sm:text-sm leading-relaxed">
              Enjoy fine dining in your room with our in-room dining service available 24/7.
            </p>
          </div>

        </div>

        {/* 5. Breakfast vs Dinner Promo Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          
          {/* Breakfast Card */}
          <div className="bg-[#FAFDF6] rounded-3xl border border-stone-200/80 p-8 flex flex-col justify-between space-y-6 hover:shadow-md transition-all">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-xl bg-amber-100/60 flex items-center justify-center text-amber-800">
                <Coffee size={24} />
              </div>
              <h3 className="font-display font-bold text-stone-900 text-xl sm:text-2xl uppercase tracking-wide">
                Breakfast & Brunch
              </h3>
              <p className="text-stone-600 text-sm leading-relaxed">
                Start your day with our sumptuous breakfast buffet featuring continental and Indian specialties, fresh pastries, and premium beverages.
              </p>
              
              <ul className="space-y-2.5 pt-2 text-stone-700 text-xs sm:text-sm">
                <li className="flex items-center space-x-2">
                  <span className="text-amber-600">✓</span>
                  <span>6:00 AM - 11:00 AM</span>
                </li>
                <li className="flex items-center space-x-2">
                  <span className="text-amber-600">✓</span>
                  <span>Buffet & À la Carte</span>
                </li>
                <li className="flex items-center space-x-2">
                  <span className="text-amber-600">✓</span>
                  <span>Fresh Juices & Coffee</span>
                </li>
              </ul>
            </div>

            <div>
              <button 
                onClick={() => openReservationModal('breakfast')}
                className="text-amber-700 hover:text-amber-800 text-xs sm:text-sm uppercase font-bold tracking-wider flex items-center space-x-1.5 transition-colors group cursor-pointer"
              >
                <span>Reserve Table</span>
                <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>

          {/* Dinner Card */}
          <div className="bg-[#FCF7F6] rounded-3xl border border-stone-200/80 p-8 flex flex-col justify-between space-y-6 hover:shadow-md transition-all">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-xl bg-rose-100/65 flex items-center justify-center text-rose-800">
                <Utensils size={24} />
              </div>
              <h3 className="font-display font-bold text-stone-900 text-xl sm:text-2xl uppercase tracking-wide">
                Dinner & Events
              </h3>
              <p className="text-stone-600 text-sm leading-relaxed">
                Experience elegant dining in the evening with our specially crafted menu. Perfect for celebrations, romantic evenings, and special family gatherings.
              </p>
              
              <ul className="space-y-2.5 pt-2 text-stone-700 text-xs sm:text-sm">
                <li className="flex items-center space-x-2">
                  <span className="text-rose-600">✓</span>
                  <span>6:30 PM - 11:00 PM</span>
                </li>
                <li className="flex items-center space-x-2">
                  <span className="text-rose-600">✓</span>
                  <span>À la Carte Menu</span>
                </li>
                <li className="flex items-center space-x-2">
                  <span className="text-rose-600">✓</span>
                  <span>Private Dining Available</span>
                </li>
              </ul>
            </div>

            <div>
              <button 
                onClick={() => openReservationModal('dinner')}
                className="text-amber-700 hover:text-amber-800 text-xs sm:text-sm uppercase font-bold tracking-wider flex items-center space-x-1.5 transition-colors group cursor-pointer"
              >
                <span>Reserve Table</span>
                <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>

        </div>

        {/* 6. Dark Reservation CTA Box */}
        <div className="bg-neutral-900 rounded-[2rem] p-8 sm:p-12 text-center text-white space-y-6 relative overflow-hidden" id="experience-culinary-cta">
          {/* Subtle backdrop pattern */}
          <div className="absolute inset-0 bg-radial-gradient from-amber-500/10 to-transparent opacity-40"></div>
          
          <div className="max-w-2xl mx-auto space-y-4 relative z-10">
            <h2 className="font-display font-bold text-2xl sm:text-4xl text-white uppercase tracking-tight">
              Experience Culinary Excellence
            </h2>
            <p className="text-stone-300 text-xs sm:text-sm md:text-base font-light max-w-lg mx-auto">
              Make your reservation at La'Pulse Dine and discover the art of fine dining combined with warm hospitality.
            </p>
            <div className="pt-4 flex flex-col items-center space-y-4">
              <button 
                onClick={() => openReservationModal('general')}
                className="bg-amber-500 hover:bg-amber-650 text-stone-950 font-bold py-3.5 px-8 rounded-xl text-xs sm:text-sm uppercase tracking-wider transition-all shadow-lg hover:scale-105 cursor-pointer flex items-center space-x-2"
              >
                <span>Book Your Table</span>
                <ArrowRight size={16} />
              </button>
              <p className="text-stone-400 text-xs">
                Or call us at <a href="tel:+919519102222" className="text-amber-400 hover:underline font-semibold">+91 95191 02222</a> for reservation assistance
              </p>
            </div>
          </div>
        </div>

        {/* 7. Beautifully Styled "Our Menu" Section */}
        <div className="space-y-12 pt-6" id="dining-menu">
          
          <div className="text-center space-y-3">
            <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-stone-900 uppercase tracking-tight">
              Our Menu
            </h2>
            
            <div className="flex items-center justify-center space-x-3 text-amber-700 text-xs sm:text-sm uppercase font-extrabold tracking-widest">
              <span className="w-12 h-[2px] bg-amber-600/30"></span>
              <span>100% Pure Vegetarian • Chef's Finest Selection</span>
              <span className="w-12 h-[2px] bg-amber-600/30"></span>
            </div>
          </div>

          {/* Menu Categories Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {menuCategories.map((cat, idx) => (
              <div 
                key={idx} 
                className="bg-white border border-stone-200/75 rounded-2xl p-6 hover:shadow-md transition-shadow flex flex-col justify-between"
              >
                <div>
                  {/* Category Title */}
                  <div className="flex items-center space-x-3 pb-4 mb-4 border-b border-stone-100">
                    <span className="text-2xl">{cat.emoji}</span>
                    <h3 className="font-display font-extrabold text-stone-900 text-base uppercase tracking-wider">
                      {cat.title}
                    </h3>
                  </div>

                  {/* Category Items list */}
                  <div className="space-y-4">
                    {cat.items.map((item, itemIdx) => (
                      <div key={itemIdx} className="flex items-baseline justify-between text-xs sm:text-sm">
                        <span className="font-medium text-stone-850 pr-2">
                          {item.name}
                        </span>
                        
                        {/* Dot leader */}
                        <span className="flex-grow border-b border-dashed border-stone-200 mx-1"></span>
                        
                        <span className="font-bold text-amber-700 font-mono pl-2 shrink-0">
                          {item.price}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-6 border-t border-stone-50 mt-6 text-center">
                  <span className="text-[10px] text-stone-400 font-mono tracking-wider uppercase">
                    ✨ Chef Special Choice
                  </span>
                </div>
              </div>
            ))}
          </div>

        </div>

      </div>

      {/* 8. Elegant Table Reservation Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-amber-900/10">
            
            {/* Header */}
            <div className="bg-neutral-900 px-6 py-5 text-white flex items-center justify-between">
              <div>
                <h3 className="font-display font-bold uppercase tracking-wider text-base sm:text-lg text-amber-400">
                  Table Reservation
                </h3>
                <p className="text-[11px] text-stone-300">
                  La'Pulse Dine • Hotel Raj Darbar
                </p>
              </div>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="text-stone-400 hover:text-white transition-colors"
              >
                <X size={22} />
              </button>
            </div>

            {/* Steps Container */}
            <div className="p-6">
              {bookingStep === 'form' ? (
                <form onSubmit={handleReservationSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1.5">
                        Your Full Name
                      </label>
                      <input 
                        type="text" 
                        required
                        value={reservationForm.name}
                        onChange={e => setReservationForm({ ...reservationForm, name: e.target.value })}
                        className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs sm:text-sm text-stone-950 focus:outline-none focus:border-amber-500 transition-colors"
                        placeholder="Amresh Sharma"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1.5">
                        Phone Number
                      </label>
                      <input 
                        type="tel" 
                        required
                        value={reservationForm.phone}
                        onChange={e => setReservationForm({ ...reservationForm, phone: e.target.value })}
                        className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs sm:text-sm text-stone-950 focus:outline-none focus:border-amber-500 transition-colors"
                        placeholder="+91 9876543210"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1.5">
                      Email Address
                    </label>
                    <input 
                      type="email" 
                      required
                      value={reservationForm.email}
                      onChange={e => setReservationForm({ ...reservationForm, email: e.target.value })}
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs sm:text-sm text-stone-950 focus:outline-none focus:border-amber-500 transition-colors"
                      placeholder="amresh@gmail.com"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1.5">
                        Select Date
                      </label>
                      <input 
                        type="date" 
                        required
                        value={reservationForm.date}
                        onChange={e => setReservationForm({ ...reservationForm, date: e.target.value })}
                        className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs text-stone-950 focus:outline-none focus:border-amber-500 transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1.5">
                        Preferred Time
                      </label>
                      <input 
                        type="time" 
                        required
                        value={reservationForm.time}
                        onChange={e => setReservationForm({ ...reservationForm, time: e.target.value })}
                        className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs text-stone-950 focus:outline-none focus:border-amber-500 transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1.5">
                        Guests Count
                      </label>
                      <select 
                        value={reservationForm.guests}
                        onChange={e => setReservationForm({ ...reservationForm, guests: e.target.value })}
                        className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs text-stone-950 focus:outline-none focus:border-amber-500 transition-colors"
                      >
                        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(n => (
                          <option key={n} value={n}>{n} {n === 1 ? 'Guest' : 'Guests'}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1.5">
                      Occasion
                    </label>
                    <select 
                      value={reservationForm.occasion}
                      onChange={e => setReservationForm({ ...reservationForm, occasion: e.target.value })}
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs text-stone-950 focus:outline-none focus:border-amber-500 transition-colors"
                    >
                      <option value="Casual Dining">Casual Dining</option>
                      <option value="Birthday Celebration">Birthday Celebration</option>
                      <option value="Anniversary Dinner">Anniversary Dinner</option>
                      <option value="Business Meeting">Business Lunch / Dinner</option>
                      <option value="Spiritual Gathering">Spiritual Get-together</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1.5">
                      Special Requests
                    </label>
                    <textarea 
                      value={reservationForm.specialRequests}
                      onChange={e => setReservationForm({ ...reservationForm, specialRequests: e.target.value })}
                      placeholder="Any specific seat choice, allergies, or decoration needs..."
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs text-stone-950 focus:outline-none focus:border-amber-500 transition-colors h-16 resize-none"
                    />
                  </div>

                  <button 
                    type="submit"
                    className="w-full bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold py-3 rounded-lg text-xs uppercase tracking-wider transition-all mt-3 flex items-center justify-center space-x-1.5 shadow"
                  >
                    <Check size={14} strokeWidth={3} />
                    <span>Confirm Table Reservation</span>
                  </button>
                </form>
              ) : (
                <div className="space-y-6 text-center py-4">
                  <div className="w-16 h-16 bg-emerald-50 border border-emerald-200 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-sm">
                    <Check size={32} strokeWidth={2.5} />
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-display font-extrabold text-stone-900 text-lg uppercase tracking-wider">
                      Reservation Successful!
                    </h4>
                    <p className="text-stone-500 text-xs sm:text-sm max-w-xs mx-auto">
                      Your table reservation at La'Pulse Dine is confirmed.
                    </p>
                  </div>

                  {/* Summary card */}
                  <div className="bg-[#FAF9F5] border border-stone-200/80 rounded-2xl p-4 text-left space-y-2.5 max-w-sm mx-auto text-xs sm:text-sm">
                    <div className="flex justify-between border-b border-stone-100 pb-2">
                      <span className="text-stone-400">Reservation ID</span>
                      <span className="font-bold text-stone-900 font-mono uppercase">{confirmedReservationDetails?.reservationId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">Name</span>
                      <span className="font-semibold text-stone-900">{confirmedReservationDetails?.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">Date & Time</span>
                      <span className="font-semibold text-stone-900">{confirmedReservationDetails?.date} @ {confirmedReservationDetails?.time}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">Guests</span>
                      <span className="font-semibold text-stone-900">{confirmedReservationDetails?.guests} Persons</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">Occasion</span>
                      <span className="font-semibold text-stone-900">{confirmedReservationDetails?.occasion}</span>
                    </div>
                  </div>

                  <button 
                    onClick={() => setIsModalOpen(false)}
                    className="bg-amber-500 hover:bg-amber-650 text-stone-950 font-bold py-2.5 px-6 rounded-lg text-xs uppercase tracking-wider transition-colors inline-block"
                  >
                    Done & Close
                  </button>
                </div>
              )}
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
