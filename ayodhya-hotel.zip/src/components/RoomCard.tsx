import React, { useState } from 'react';
import { Star, Users, ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';
import { Room } from '../types';

interface RoomCardProps {
  key?: string | number;
  room: Room;
  onBook: (roomId: string) => void;
}

export default function RoomCard({ room, onBook }: RoomCardProps) {
  const [currentImgIndex, setCurrentImgIndex] = useState(0);
  const images = room.images && room.images.length > 0 ? room.images : [room.image];

  const nextImage = () => {
    setCurrentImgIndex((prev) => (prev + 1) % images.length);
  };

  const prevImage = () => {
    setCurrentImgIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  return (
    <div className="bg-white rounded-[2rem] overflow-hidden border border-stone-200/60 shadow-md hover:shadow-xl transition-all duration-500 flex flex-col h-full group">
      {/* 1. Image Slider Section */}
      <div className="relative h-72 sm:h-80 overflow-hidden w-full select-none bg-stone-100">
        <img
          src={images[currentImgIndex]}
          alt={room.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover transition-all duration-500 scale-100 group-hover:scale-[1.02]"
        />
        {/* Subtle dark gradient overlay at the bottom to ensure text readability */}
        <div className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-black/50 via-black/20 to-transparent"></div>

        {/* Navigation Arrows */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            prevImage();
          }}
          className="absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-black/30 hover:bg-black/60 text-white flex items-center justify-center transition-all border border-white/10 opacity-0 group-hover:opacity-100 focus:opacity-100"
          aria-label="Previous Image"
        >
          <ChevronLeft size={18} />
        </button>
        <button
          onClick={(e) => {
            e.stopPropagation();
            nextImage();
          }}
          className="absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-black/30 hover:bg-black/60 text-white flex items-center justify-center transition-all border border-white/10 opacity-0 group-hover:opacity-100 focus:opacity-100"
          aria-label="Next Image"
        >
          <ChevronRight size={18} />
        </button>

        {/* Dot Indicators */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-1.5 z-10">
          {images.map((_, idx) => (
            <button
              key={idx}
              onClick={(e) => {
                e.stopPropagation();
                setCurrentImgIndex(idx);
              }}
              className={`h-1.5 rounded-full transition-all ${
                idx === currentImgIndex ? 'w-4 bg-white' : 'w-1.5 bg-white/40'
              }`}
              aria-label={`Go to slide ${idx + 1}`}
            />
          ))}
        </div>

        {/* Slide Count Indicator Badge */}
        <div className="absolute bottom-4 right-4 bg-black/65 text-white text-[11px] font-bold px-2.5 py-1 rounded-md tracking-wider">
          {currentImgIndex + 1}/{images.length}
        </div>
      </div>

      {/* 2. Room Content Details */}
      <div className="p-6 sm:p-7 flex-1 flex flex-col justify-between">
        <div className="space-y-4">
          {/* Header Title & Star Rating Row */}
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-display font-extrabold text-xl sm:text-2xl text-stone-900 tracking-tight leading-tight uppercase">
              {room.name}
            </h3>
            <div className="flex items-center space-x-0.5 text-amber-500 shrink-0 pt-1">
              {[...Array(5)].map((_, i) => (
                <Star key={i} size={15} fill="currentColor" className="stroke-amber-500" />
              ))}
            </div>
          </div>

          {/* Description Block */}
          <p className="text-stone-600 text-sm leading-relaxed font-normal">
            {room.description}
          </p>

          {/* Elegant Beige Specifications Tiles Grid */}
          <div className="grid grid-cols-3 gap-2.5 pt-2">
            {/* Size Tile */}
            <div className="bg-[#FAF5ED] rounded-xl p-3 text-center border border-[#F0E6DA]/50 flex flex-col justify-center items-center">
              <span className="block text-[9px] text-stone-500 uppercase tracking-widest font-extrabold mb-1">
                Size
              </span>
              <span className="block text-xs sm:text-sm font-extrabold text-stone-850">
                {room.size}
              </span>
            </div>

            {/* Guests Tile */}
            <div className="bg-[#FAF5ED] rounded-xl p-3 text-center border border-[#F0E6DA]/50 flex flex-col justify-center items-center">
              <span className="block text-[9px] text-stone-500 uppercase tracking-widest font-extrabold mb-1">
                Guests
              </span>
              <div className="flex items-center justify-center space-x-1">
                <Users size={12} className="text-stone-600" />
                <span className="block text-xs sm:text-sm font-extrabold text-stone-850">
                  {room.capacity}
                </span>
              </div>
            </div>

            {/* Price Tile */}
            <div className="bg-[#FAF5ED] rounded-xl p-3 text-center border border-[#F0E6DA]/50 flex flex-col justify-center items-center">
              <span className="block text-[9px] text-stone-500 uppercase tracking-widest font-extrabold mb-1">
                Per Night
              </span>
              <span className="block text-xs sm:text-sm font-extrabold text-amber-800">
                ₹{room.price.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Service Badge Pills Row */}
          <div className="flex flex-wrap gap-2 pt-2">
            {room.tags?.map((tag, idx) => (
              <span
                key={idx}
                className="bg-[#FDF6E2] text-[#B28A1C] px-3 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* View Details Action Button */}
        <div className="pt-6">
          <button
            onClick={() => onBook(room.id)}
            className="w-full bg-[#d28a00] hover:bg-amber-600 text-white font-bold py-3.5 px-6 rounded-xl text-xs sm:text-sm uppercase tracking-wider transition-all duration-300 flex items-center justify-center space-x-2 shadow-sm hover:shadow-md cursor-pointer"
          >
            <span>View Details</span>
            <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
          </button>
        </div>
      </div>
    </div>
  );
}
