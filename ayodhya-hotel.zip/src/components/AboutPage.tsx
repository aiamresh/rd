import React, { useState } from 'react';
import { 
  Clock, 
  Waves, 
  ArrowUpDown, 
  Leaf, 
  Utensils, 
  Briefcase, 
  User, 
  Dumbbell, 
  Wifi, 
  Wine, 
  Check, 
  ArrowRight, 
  Trophy, 
  Users, 
  Sparkles 
} from 'lucide-react';

interface AboutPageProps {
  onBook: () => void;
}

interface AmenityDetail {
  id: string;
  title: string;
  gridDesc: string;
  fullDesc: string;
  features: string[];
  image: string;
  icon: React.ComponentType<any>;
}

export default function AboutPage({ onBook }: AboutPageProps) {
  const [selectedAmenityId, setSelectedAmenityId] = useState<string>('check-in');

  const amenities: AmenityDetail[] = [
    {
      id: 'check-in',
      title: '24/7 Check-in',
      gridDesc: 'Flexible arrival and departure times with round-the-clock fr...',
      fullDesc: 'Flexible arrival and departure times with round-the-clock front desk service. We welcome late arrivals and early departures without any additional charges.',
      features: [
        'Round-the-clock reception',
        'Late arrival welcome',
        'Early checkout welcome',
        'Express check-in/out',
        'Baggage storage'
      ],
      image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=800',
      icon: Clock
    },
    {
      id: 'pool',
      title: 'Swimming Pool',
      gridDesc: 'Olympic-size outdoor swimming pool with professional supervi...',
      fullDesc: 'Take a refreshing dip in our pristine, temperature-controlled Olympic-size swimming pool. Framed by comfortable loungers, it offers a tranquil retreat under professional supervision.',
      features: [
        'Olympic-size pool dimensions',
        'Temperature-controlled water',
        'Certified lifeguards on duty',
        'Complimentary poolside towels',
        'Separate kid\'s shallow area'
      ],
      image: 'https://images.unsplash.com/photo-1576013551627-0cc20b96c2a7?auto=format&fit=crop&q=80&w=800',
      icon: Waves
    },
    {
      id: 'elevator',
      title: 'Elevator Service',
      gridDesc: 'Modern high-speed elevators throughout the 8-story building...',
      fullDesc: 'Enjoy seamless accessibility across all floors of our 8-story hotel. Our ultra-modern, high-speed capsule elevators ensure rapid transit with whisper-quiet operation.',
      features: [
        'Whisper-quiet high-speed lifts',
        'Capsule panoramic design',
        'Full accessibility for all guests',
        'Emergency backup power systems',
        'Smooth touch controls'
      ],
      image: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&q=80&w=800',
      icon: ArrowUpDown
    },
    {
      id: 'garden',
      title: 'Lush Garden',
      gridDesc: 'Beautiful landscaped gardens spanning 2 acres with walking p...',
      fullDesc: 'Immerse yourself in serenity within our masterfully landscaped gardens spanning over 2 acres. Experience manicured walking pathways, serene flower beds, and custom peaceful seating spots.',
      features: [
        '2-acre manicured layout',
        'Dedicated peaceful seating spots',
        'Morning yoga & meditation lawns',
        'Scenic traditional fountains',
        'Ambient evening illumination'
      ],
      image: 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&q=80&w=800',
      icon: Leaf
    },
    {
      id: 'banquet',
      title: 'Banquet Hall',
      gridDesc: 'Elegant multi-purpose banquet hall with a capacity of up to ...',
      fullDesc: 'Host grand spiritual gatherings, traditional weddings, and corporate events in our premium multi-purpose banquet hall. Equipped with high-tech audio-visual gear and flexible partitions.',
      features: [
        'Spacious 500+ guest capacity',
        'Fully air-conditioned luxury hall',
        'Advanced audio-visual systems',
        'Custom satvik catering options',
        'Dedicated bridal suites'
      ],
      image: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&q=80&w=800',
      icon: Utensils
    },
    {
      id: 'conference',
      title: 'Conference Room',
      gridDesc: 'State-of-the-art conference rooms equipped with the latest t...',
      fullDesc: 'Empower your corporate discussions in our high-end conference rooms. Outfitted with high-speed internet, smart displays, ergonomic seating, and complete administrative backup support.',
      features: [
        'Smart 4K screen displays',
        'High-speed videoconferencing',
        'Ergonomic leather seating',
        'Custom writing boards & flipcharts',
        'Complimentary tea & coffee bar'
      ],
      image: 'https://images.unsplash.com/photo-1431540015161-0bf868a2d407?auto=format&fit=crop&q=80&w=800',
      icon: Briefcase
    },
    {
      id: 'driver-dorm',
      title: 'Driver Dormitory',
      gridDesc: 'Comfortable accommodation facility exclusively for drivers a...',
      fullDesc: 'We offer complete peace of mind for your personal travel escorts with our comfortable, hygienic, and separate driver dormitory facility. Safe bunk beds and private dining are fully included.',
      features: [
        'Comfortable clean bunk beds',
        'Hygienic personal washrooms',
        'Complimentary meals & beverages',
        'Secure vehicle parking spots',
        '24/7 dedicated security monitoring'
      ],
      image: 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&q=80&w=800',
      icon: User
    },
    {
      id: 'fitness',
      title: 'Fitness Center',
      gridDesc: 'Fully equipped gymnasium with modern fitness equipment, expe...',
      fullDesc: 'Keep up with your dynamic fitness routine at our professional fitness center. Features a comprehensive array of cardio machines, strength trainers, free weights, and certified coaches.',
      features: [
        'Premium cardio treadmill machines',
        'Comprehensive free weights section',
        'Advanced multi-station trainers',
        'Certified on-floor fitness coaches',
        'Complimentary energy water bar'
      ],
      image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80&w=800',
      icon: Dumbbell
    },
    {
      id: 'wifi',
      title: 'WiFi Throughout',
      gridDesc: 'High-speed, reliable WiFi available across the entire proper...',
      fullDesc: 'Stay connected smoothly with our high-speed, enterprise-grade WiFi network. Accessible across all rooms, dining halls, gardens, lobbies, and common areas without any dead zones.',
      features: [
        'Enterprise-grade high bandwidth',
        'Seamless auto-roaming protocol',
        'Connect multiple guest devices',
        'Secure encrypted transactions',
        '24/7 technical IT helpdesk'
      ],
      image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80&w=800',
      icon: Wifi
    },
    {
      id: 'wine',
      title: 'Wine & Spirits',
      gridDesc: 'Premium collection of wines, spirits, and beverages from aro...',
      fullDesc: 'Experience an elegant curated beverage collection featuring premium mocktails, specialized local herbal brews, and fine international non-alcoholic grape juices served in our ambient lounge.',
      features: [
        'Custom herbal non-alcoholic recipes',
        'Sophisticated cocktail-style service',
        'Premium international sparkling juices',
        'Ambient luxury lounge seating',
        'Bespoke tableside preparation'
      ],
      image: 'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&q=80&w=800',
      icon: Wine
    }
  ];

  const selectedAmenity = amenities.find(a => a.id === selectedAmenityId) || amenities[0];

  return (
    <div className="bg-[#FAF9F5] min-h-screen">
      {/* 1. Header Banner - Dark Elegant Theme */}
      <div className="bg-neutral-900 pt-32 pb-20 px-4 text-center">
        <div className="max-w-4xl mx-auto space-y-4">
          <h1 className="font-display font-black text-white text-4xl sm:text-5xl md:text-6xl uppercase tracking-tight">
            World-Class Amenities
          </h1>
          <p className="text-stone-300 text-sm sm:text-base md:text-lg font-light tracking-wide max-w-2xl mx-auto">
            Discover our comprehensive range of facilities designed for your comfort and convenience
          </p>
        </div>
      </div>

      {/* 2. Main Content Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
        
        {/* Interactive Amenities Selector Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-16" id="amenities-selector-grid">
          {amenities.map((item) => {
            const isSelected = item.id === selectedAmenityId;
            const Icon = item.icon;
            
            return (
              <button
                key={item.id}
                onClick={() => setSelectedAmenityId(item.id)}
                className={`p-6 rounded-[1.5rem] border text-left transition-all duration-300 flex flex-col justify-between h-48 group cursor-pointer focus:outline-none ${
                  isSelected
                    ? 'bg-[#d28a00] border-[#d28a00] text-white shadow-lg scale-[1.02]'
                    : 'bg-white border-stone-200/80 text-stone-800 hover:border-stone-400 hover:shadow-md'
                }`}
              >
                <div className="space-y-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-colors ${
                    isSelected ? 'bg-white/20 text-white' : 'bg-[#FAF5ED] text-amber-700'
                  }`}>
                    <Icon size={24} />
                  </div>
                  <div>
                    <h3 className={`font-display font-extrabold text-base uppercase tracking-wider mb-2 ${
                      isSelected ? 'text-white' : 'text-stone-900'
                    }`}>
                      {item.title}
                    </h3>
                    <p className={`text-xs leading-relaxed line-clamp-2 ${
                      isSelected ? 'text-amber-50/90' : 'text-stone-500'
                    }`}>
                      {item.gridDesc}
                    </p>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* 3. Detailed Showcase Panel of Selected Amenity */}
        <div className="bg-white rounded-[2rem] border border-stone-200/80 p-6 sm:p-10 md:p-12 shadow-xl mb-16" id="selected-amenity-panel">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 md:gap-12 items-center">
            
            {/* Left Col: Image */}
            <div className="lg:col-span-6 h-72 sm:h-96 rounded-2xl overflow-hidden shadow-md">
              <img
                src={selectedAmenity.image}
                alt={selectedAmenity.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Right Col: Details */}
            <div className="lg:col-span-6 space-y-6">
              <h2 className="font-display font-black text-3xl sm:text-4xl text-stone-900 uppercase tracking-tight leading-none">
                {selectedAmenity.title}
              </h2>
              
              <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
                {selectedAmenity.fullDesc}
              </p>

              <div className="space-y-3 pt-2">
                <h4 className="font-bold text-stone-900 text-sm uppercase tracking-wider">
                  Features:
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {selectedAmenity.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center space-x-2.5 text-xs text-stone-750 font-medium">
                      <div className="w-5 h-5 rounded-full bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-700 shrink-0">
                        <Check size={12} strokeWidth={3} />
                      </div>
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4">
                <button
                  onClick={onBook}
                  className="bg-[#d28a00] hover:bg-amber-600 text-white font-bold py-3.5 px-8 rounded-xl text-xs sm:text-sm uppercase tracking-wider transition-all duration-300 flex items-center space-x-2 shadow-sm hover:shadow-md cursor-pointer"
                >
                  <span>Book Your Stay</span>
                  <ArrowRight size={16} />
                </button>
              </div>
            </div>

          </div>
        </div>

        {/* 4. Brand Value Pillars (Premium Quality, Professional Staff, Excellence) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-6 border-t border-stone-200/60" id="brand-values">
          {/* Pillar 1 */}
          <div className="flex flex-col items-center text-center p-4">
            <div className="w-14 h-14 rounded-full bg-amber-50 border border-amber-200/50 flex items-center justify-center text-amber-700 mb-4 shadow-sm">
              <Trophy size={26} />
            </div>
            <h4 className="font-display font-extrabold text-stone-900 text-lg uppercase tracking-wider mb-2">
              Premium Quality
            </h4>
            <p className="text-stone-500 text-xs sm:text-sm leading-relaxed max-w-xs">
              All facilities are maintained to international standards with regular upgrades
            </p>
          </div>

          {/* Pillar 2 */}
          <div className="flex flex-col items-center text-center p-4">
            <div className="w-14 h-14 rounded-full bg-amber-50 border border-amber-200/50 flex items-center justify-center text-amber-700 mb-4 shadow-sm">
              <Users size={26} />
            </div>
            <h4 className="font-display font-extrabold text-stone-900 text-lg uppercase tracking-wider mb-2">
              Professional Staff
            </h4>
            <p className="text-stone-500 text-xs sm:text-sm leading-relaxed max-w-xs">
              Trained and courteous staff available 24/7 to assist with all your needs
            </p>
          </div>

          {/* Pillar 3 */}
          <div className="flex flex-col items-center text-center p-4">
            <div className="w-14 h-14 rounded-full bg-amber-50 border border-amber-200/50 flex items-center justify-center text-amber-700 mb-4 shadow-sm">
              <Sparkles size={26} />
            </div>
            <h4 className="font-display font-extrabold text-stone-900 text-lg uppercase tracking-wider mb-2">
              Excellence
            </h4>
            <p className="text-stone-500 text-xs sm:text-sm leading-relaxed max-w-xs">
              Commitment to providing exceptional service and unforgettable experiences
            </p>
          </div>
        </div>

      </div>
    </div>
  );
}
