import React, { useState } from 'react';
import { 
  Building, 
  Trees, 
  Target, 
  BarChart3, 
  Users, 
  Utensils, 
  Palette, 
  Cpu, 
  Calendar, 
  Briefcase, 
  Heart, 
  BookOpen, 
  X, 
  Check, 
  Phone, 
  Send, 
  ArrowRight,
  Sparkles,
  Shield,
  Camera,
  GlassWater,
  Mail,
  Clock
} from 'lucide-react';

interface ServicesPageProps {
  onBook?: () => void;
  onBackToHome?: () => void;
}

export default function ServicesPage({ onBook, onBackToHome }: ServicesPageProps) {
  const [isInquiryModalOpen, setIsInquiryModalOpen] = useState(false);
  const [inquiryType, setInquiryType] = useState<string>('Wedding & Reception');
  const [inquiryStep, setInquiryStep] = useState<'form' | 'success'>('form');
  const [inquiryForm, setInquiryForm] = useState({
    name: '',
    email: '',
    phone: '',
    date: new Date().toISOString().split('T')[0],
    guests: '150',
    venue: 'Grand Banquet Hall',
    specialRequests: ''
  });

  const [confirmedInquiryDetails, setConfirmedInquiryDetails] = useState<any>(null);

  const handleInquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const details = {
      inquiryId: 'EVT-' + Math.floor(100000 + Math.random() * 900000),
      ...inquiryForm,
      eventType: inquiryType
    };
    setConfirmedInquiryDetails(details);
    setInquiryStep('success');
  };

  const openInquiryModal = (type: string = 'Wedding & Reception') => {
    setInquiryType(type);
    setIsInquiryModalOpen(true);
    setInquiryStep('form');
  };

  const eventTypes = [
    {
      title: 'Corporate Events',
      capacity: 'Up to 500 guests',
      desc: 'Conferences, product launches, seminars, and business meetings with state-of-the-art AV facilities.',
      icon: Briefcase,
      features: ['WiFi & High-speed Internet', 'AV & Projection Systems', 'Sound System', 'Breakout Rooms']
    },
    {
      title: 'Weddings & Receptions',
      capacity: 'Up to 600 guests',
      desc: 'Grand wedding celebrations with elegant ballrooms, expert catering, and dedicated event planning.',
      icon: Heart,
      features: ['Banquet Hall', 'Decorative Services', 'Multi-cuisine Catering', 'In-house Florist']
    },
    {
      title: 'Social Gatherings',
      capacity: '10 to 300 guests',
      desc: 'Intimate dinners, cocktail parties, anniversary celebrations, and milestone events.',
      icon: GlassWater,
      features: ['Customized Menus', 'Bar Service', 'Private Rooms', 'Entertainment Options']
    },
    {
      title: 'Seminars & Workshops',
      capacity: 'Up to 250 participants',
      desc: 'Professional training programs and interactive workshops with all necessary technical support.',
      icon: BookOpen,
      features: ['Flexible Configurations', 'Tech Support', 'Catering', 'Certification Setup']
    }
  ];

  const facilities = [
    {
      title: 'Grand Banquet Hall',
      size: '5,000 sq ft',
      capacity: 'Up to 600 seated, 1000 cocktail',
      desc: 'The largest venue with crystal chandeliers, elegant décor, and perfect acoustics.',
      icon: Building
    },
    {
      title: 'Lakeside Pavilion',
      size: '3,000 sq ft',
      capacity: 'Up to 400 seated, 600 cocktail',
      desc: 'Open-air venue with garden views, perfect for outdoor celebrations.',
      icon: Trees
    },
    {
      title: 'Conference Center',
      size: '2,500 sq ft',
      capacity: 'Up to 300 participants',
      desc: 'Modern facilities with breakout rooms and latest technology.',
      icon: Target
    },
    {
      title: 'Elegant Boardroom',
      size: '1,500 sq ft',
      capacity: 'Up to 100 participants',
      desc: 'Intimate setting for executive meetings and small functions.',
      icon: BarChart3
    }
  ];

  const services = [
    {
      title: 'Catering',
      icon: Utensils,
      items: ['Multi-cuisine menus', 'Customized dishes', 'Bar service', 'Beverage selection']
    },
    {
      title: 'Décor & Design',
      icon: Palette,
      items: ['Professional decorators', 'Floral arrangements', 'Lighting design', 'Table settings']
    },
    {
      title: 'Technical Support',
      icon: Cpu,
      items: ['Sound system', 'Projection & AV', 'WiFi connectivity', 'Video recording']
    },
    {
      title: 'Event Planning',
      icon: Calendar,
      items: ['Full coordination', 'Timeline management', 'Guest management', 'Vendor coordination']
    },
    {
      title: 'Accommodation',
      icon: Building,
      items: ['Discounted room rates', 'VIP suites', 'Special packages', 'Group arrangements']
    },
    {
      title: 'Additional Services',
      icon: Sparkles,
      items: ['Valet parking', 'Security', 'Photography', 'Housekeeping']
    }
  ];

  return (
    <div className="bg-[#FAF9F5] min-h-screen font-sans text-stone-800">
      
      {/* 1. Header Banner */}
      <div className="bg-neutral-900 pt-32 pb-20 px-4 text-center border-b border-amber-900/20">
        <div className="max-w-4xl mx-auto space-y-4">
          <span className="text-amber-400 font-bold uppercase tracking-[0.2em] text-xs sm:text-sm">
            ✨ Premium Venues & Occasions At Hotel Raj Darbar
          </span>
          <h1 className="font-display font-extrabold text-white text-4xl sm:text-5xl md:text-6xl uppercase tracking-tight">
            Events & Functions
          </h1>
          <p className="text-stone-300 text-sm sm:text-base md:text-lg font-light tracking-wide max-w-2xl mx-auto">
            Host your special occasions at Hotel Raj Darbar with world-class facilities and impeccable service
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-24">
        
        {/* 2. Types of Events */}
        <div className="space-y-12">
          <div className="text-center space-y-3">
            <h2 className="font-display font-extrabold text-3xl sm:text-4xl text-stone-900 uppercase tracking-tight">
              Types of Events
            </h2>
            <p className="text-stone-550 text-sm sm:text-base font-medium text-amber-700 tracking-wide uppercase">
              Perfect venues for every occasion
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {eventTypes.map((evt, idx) => {
              const Icon = evt.icon;
              return (
                <div 
                  key={idx} 
                  className="bg-white border border-stone-200/80 rounded-2xl p-8 hover:shadow-md transition-shadow flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="w-12 h-12 rounded-xl bg-amber-50 flex items-center justify-center text-amber-700 shrink-0">
                        <Icon size={24} />
                      </div>
                      <span className="bg-amber-100/60 text-amber-900 text-xs font-semibold px-3 py-1 rounded-full">
                        {evt.capacity}
                      </span>
                    </div>

                    <h3 className="font-display font-extrabold text-stone-900 text-xl uppercase tracking-wide">
                      {evt.title}
                    </h3>

                    <p className="text-stone-600 text-sm leading-relaxed">
                      {evt.desc}
                    </p>

                    <div className="pt-4 border-t border-stone-100">
                      <p className="text-[11px] font-bold text-stone-400 uppercase tracking-wider mb-2">Key Features:</p>
                      <div className="grid grid-cols-2 gap-2">
                        {evt.features.map((feat, fIdx) => (
                          <div key={fIdx} className="flex items-center space-x-2 text-stone-700 text-xs">
                            <span className="text-amber-500 font-bold">•</span>
                            <span>{feat}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="pt-6 mt-6 border-t border-stone-50">
                    <button 
                      onClick={() => openInquiryModal(evt.title)}
                      className="text-amber-700 hover:text-amber-800 text-xs sm:text-sm uppercase font-bold tracking-wider flex items-center space-x-1.5 transition-colors group cursor-pointer"
                    >
                      <span>Inquire for {evt.title.split(' ')[0]}</span>
                      <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 3. Our Event Facilities */}
        <div className="space-y-12">
          <div className="text-center space-y-3">
            <h2 className="font-display font-extrabold text-3xl sm:text-4xl text-stone-900 uppercase tracking-tight">
              Our Event Facilities
            </h2>
            <p className="text-stone-550 text-sm sm:text-base font-medium text-amber-700 tracking-wide uppercase">
              World-class venues for your special moments
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {facilities.map((fac, idx) => {
              const Icon = fac.icon;
              return (
                <div 
                  key={idx} 
                  className="bg-white border border-stone-200/80 rounded-2xl p-8 hover:shadow-md transition-shadow flex items-start space-x-6"
                >
                  <div className="w-14 h-14 rounded-2xl bg-amber-50 flex items-center justify-center text-amber-700 shrink-0">
                    <Icon size={28} />
                  </div>
                  <div className="space-y-3 flex-grow">
                    <h3 className="font-display font-extrabold text-stone-900 text-xl uppercase tracking-wide">
                      {fac.title}
                    </h3>
                    <p className="text-xs font-mono font-bold text-amber-700 uppercase tracking-wider">
                      {fac.size} | Capacity: {fac.capacity}
                    </p>
                    <p className="text-stone-600 text-sm leading-relaxed">
                      {fac.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 4. Complete Event Services */}
        <div className="space-y-12">
          <div className="text-center space-y-3">
            <h2 className="font-display font-extrabold text-3xl sm:text-4xl text-stone-900 uppercase tracking-tight">
              Complete Event Services
            </h2>
            <p className="text-stone-550 text-sm sm:text-base font-medium text-amber-700 tracking-wide uppercase">
              Everything you need for a flawless celebration
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((srv, idx) => {
              const Icon = srv.icon;
              return (
                <div 
                  key={idx} 
                  className="bg-white border border-stone-200/85 rounded-2xl p-6 hover:shadow-md transition-shadow space-y-4"
                >
                  <div className="flex items-center space-x-3 pb-3 border-b border-stone-100">
                    <div className="w-10 h-10 rounded-lg bg-amber-50 flex items-center justify-center text-amber-700">
                      <Icon size={20} />
                    </div>
                    <h3 className="font-display font-extrabold text-stone-900 text-base uppercase tracking-wider">
                      {srv.title}
                    </h3>
                  </div>

                  <ul className="space-y-2 text-stone-650 text-sm">
                    {srv.items.map((item, itemIdx) => (
                      <li key={itemIdx} className="flex items-center space-x-2">
                        <span className="text-amber-500 text-base">•</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </div>

        {/* 5. Primary Event CTA Card */}
        <div className="bg-neutral-900 rounded-[2rem] p-8 sm:p-12 text-center text-white space-y-6 relative overflow-hidden" id="plan-event-cta">
          <div className="absolute inset-0 bg-radial-gradient from-amber-500/10 to-transparent opacity-40"></div>
          
          <div className="max-w-2xl mx-auto space-y-4 relative z-10">
            <h2 className="font-display font-bold text-2xl sm:text-4xl text-white uppercase tracking-tight">
              Plan Your Perfect Event
            </h2>
            <p className="text-stone-300 text-xs sm:text-sm md:text-base font-light max-w-lg mx-auto">
              Contact our event management team to discuss your special occasion and create unforgettable memories.
            </p>
            <div className="pt-4 flex flex-wrap justify-center gap-4">
              <button 
                onClick={() => openInquiryModal()}
                className="bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold py-3.5 px-8 rounded-xl text-xs sm:text-sm uppercase tracking-wider transition-all shadow-lg hover:scale-105 cursor-pointer flex items-center space-x-2"
              >
                <span>Inquiry Form</span>
                <Send size={16} />
              </button>
              <a 
                href="tel:+917234000983"
                className="bg-white hover:bg-stone-100 text-stone-950 font-bold py-3.5 px-8 rounded-xl text-xs sm:text-sm uppercase tracking-wider transition-all shadow-lg hover:scale-105 cursor-pointer flex items-center space-x-2 border border-stone-200"
              >
                <Phone size={16} />
                <span>Call Now</span>
              </a>
            </div>
          </div>
        </div>

      </div>

      {/* 6. Event Inquiry Modal */}
      {isInquiryModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-amber-900/10">
            
            {/* Header */}
            <div className="bg-neutral-900 px-6 py-5 text-white flex items-center justify-between">
              <div>
                <h3 className="font-display font-bold uppercase tracking-wider text-base sm:text-lg text-amber-400">
                  Event Inquiry
                </h3>
                <p className="text-[11px] text-stone-300">
                  Host Your Occasion • Hotel Raj Darbar
                </p>
              </div>
              <button 
                onClick={() => setIsInquiryModalOpen(false)}
                className="text-stone-400 hover:text-white transition-colors"
              >
                <X size={22} />
              </button>
            </div>

            {/* Steps Container */}
            <div className="p-6">
              {inquiryStep === 'form' ? (
                <form onSubmit={handleInquirySubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1.5">
                        Your Full Name
                      </label>
                      <input 
                        type="text" 
                        required
                        value={inquiryForm.name}
                        onChange={e => setInquiryForm({ ...inquiryForm, name: e.target.value })}
                        className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs sm:text-sm text-stone-950 focus:outline-none focus:border-amber-500 transition-colors"
                        placeholder="Amresh Sharma"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1.5">
                        Phone Number
                      </label>
                      <input 
                        type="tel" 
                        required
                        value={inquiryForm.phone}
                        onChange={e => setInquiryForm({ ...inquiryForm, phone: e.target.value })}
                        className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs sm:text-sm text-stone-950 focus:outline-none focus:border-amber-500 transition-colors"
                        placeholder="+91 9876543210"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1.5">
                      Email Address
                    </label>
                    <input 
                      type="email" 
                      required
                      value={inquiryForm.email}
                      onChange={e => setInquiryForm({ ...inquiryForm, email: e.target.value })}
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs sm:text-sm text-stone-950 focus:outline-none focus:border-amber-500 transition-colors"
                      placeholder="amresh@gmail.com"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1.5">
                        Event Date
                      </label>
                      <input 
                        type="date" 
                        required
                        value={inquiryForm.date}
                        onChange={e => setInquiryForm({ ...inquiryForm, date: e.target.value })}
                        className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs text-stone-950 focus:outline-none focus:border-amber-500 transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1.5">
                        Guest Count
                      </label>
                      <input 
                        type="number" 
                        required
                        min="10"
                        max="1000"
                        value={inquiryForm.guests}
                        onChange={e => setInquiryForm({ ...inquiryForm, guests: e.target.value })}
                        className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs text-stone-950 focus:outline-none focus:border-amber-500 transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1.5">
                        Event Type
                      </label>
                      <select 
                        value={inquiryType}
                        onChange={e => setInquiryType(e.target.value)}
                        className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs text-stone-950 focus:outline-none focus:border-amber-500 transition-colors"
                      >
                        <option value="Corporate Events">Corporate Events</option>
                        <option value="Wedding & Reception">Wedding & Reception</option>
                        <option value="Social Gathering">Social Gathering</option>
                        <option value="Seminars & Workshops">Seminars & Workshops</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1.5">
                      Preferred Venue
                    </label>
                    <select 
                      value={inquiryForm.venue}
                      onChange={e => setInquiryForm({ ...inquiryForm, venue: e.target.value })}
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs text-stone-950 focus:outline-none focus:border-amber-500 transition-colors"
                    >
                      <option value="Grand Banquet Hall">Grand Banquet Hall</option>
                      <option value="Lakeside Pavilion">Lakeside Pavilion</option>
                      <option value="Conference Center">Conference Center</option>
                      <option value="Elegant Boardroom">Elegant Boardroom</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1.5">
                      Special Requests / Event Details
                    </label>
                    <textarea 
                      value={inquiryForm.specialRequests}
                      onChange={e => setInquiryForm({ ...inquiryForm, specialRequests: e.target.value })}
                      placeholder="E.g., Catering preferences, stage decoration, AV requirements, room block requests..."
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs text-stone-950 focus:outline-none focus:border-amber-500 transition-colors h-20 resize-none"
                    />
                  </div>

                  <button 
                    type="submit"
                    className="w-full bg-amber-500 hover:bg-amber-650 text-stone-950 font-bold py-3 rounded-lg text-xs uppercase tracking-wider transition-all mt-3 flex items-center justify-center space-x-1.5 shadow"
                  >
                    <Check size={14} strokeWidth={3} />
                    <span>Submit Event Inquiry</span>
                  </button>
                </form>
              ) : (
                <div className="space-y-6 text-center py-4">
                  <div className="w-16 h-16 bg-emerald-50 border border-emerald-200 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-sm">
                    <Check size={32} strokeWidth={2.5} />
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-display font-extrabold text-stone-900 text-lg uppercase tracking-wider">
                      Inquiry Submitted!
                    </h4>
                    <p className="text-stone-500 text-xs sm:text-sm max-w-xs mx-auto">
                      Our event management coordinator will review your details and contact you shortly.
                    </p>
                  </div>

                  {/* Summary card */}
                  <div className="bg-[#FAF9F5] border border-stone-200/80 rounded-2xl p-4 text-left space-y-2.5 max-w-sm mx-auto text-xs sm:text-sm">
                    <div className="flex justify-between border-b border-stone-100 pb-2">
                      <span className="text-stone-400">Inquiry Ref ID</span>
                      <span className="font-bold text-stone-900 font-mono uppercase">{confirmedInquiryDetails?.inquiryId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">Name</span>
                      <span className="font-semibold text-stone-900">{confirmedInquiryDetails?.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">Event Type</span>
                      <span className="font-semibold text-stone-900">{confirmedInquiryDetails?.eventType}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">Venue</span>
                      <span className="font-semibold text-stone-900">{confirmedInquiryDetails?.venue}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">Guests</span>
                      <span className="font-semibold text-stone-900">{confirmedInquiryDetails?.guests} Persons</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">Date</span>
                      <span className="font-semibold text-stone-900">{confirmedInquiryDetails?.date}</span>
                    </div>
                  </div>

                  <button 
                    onClick={() => setIsInquiryModalOpen(false)}
                    className="bg-amber-500 hover:bg-amber-650 text-stone-950 font-bold py-2.5 px-6 rounded-lg text-xs uppercase tracking-wider transition-colors inline-block"
                  >
                    Done & Close
                  </button>
                </div>
              )}
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
