import React, { useState } from 'react';
import { 
  Mail, 
  Phone, 
  MapPin, 
  Clock, 
  MessageSquare, 
  Send, 
  Check, 
  ExternalLink,
  ChevronRight
} from 'lucide-react';

interface ContactPageProps {
  onBackToHome?: () => void;
}

export default function ContactPage({ onBackToHome }: ContactPageProps) {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API request
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      setFormState({
        name: '',
        email: '',
        phone: '',
        subject: '',
        message: ''
      });
    }, 1200);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormState(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="bg-[#FAF9F5] min-h-screen text-stone-800 font-sans">
      
      {/* 1. Header Banner */}
      <div className="relative bg-neutral-900 pt-32 pb-24 px-4 text-center overflow-hidden border-b border-amber-900/20">
        <div className="absolute inset-0 bg-gradient-to-r from-amber-500/10 via-transparent to-amber-500/10 opacity-30"></div>
        <div className="max-w-4xl mx-auto space-y-4 relative z-10">
          <span className="text-amber-400 font-bold uppercase tracking-[0.2em] text-xs sm:text-sm block">
            ✨ Get In Touch With Us
          </span>
          <h1 className="font-display font-extrabold text-white text-4xl sm:text-5xl md:text-6xl uppercase tracking-tight">
            Contact Us
          </h1>
          <p className="text-stone-300 text-sm sm:text-base md:text-lg font-light tracking-wide max-w-2xl mx-auto">
            Get in touch with us for reservations, inquiries, or feedback
          </p>
        </div>
      </div>

      {/* 2. Main Columns Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Direct Info */}
          <div className="lg:col-span-5 space-y-8">
            <div>
              <h2 className="font-display font-black text-3xl sm:text-4xl text-stone-900 uppercase tracking-tight">
                Get In Touch
              </h2>
              <div className="w-16 h-1 bg-amber-500 mt-3 rounded-full"></div>
            </div>

            <div className="space-y-6">
              
              {/* Email Address */}
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 rounded-xl bg-amber-600 flex items-center justify-center text-white shrink-0 shadow-md">
                  <Mail size={22} />
                </div>
                <div className="space-y-1">
                  <h4 className="font-bold text-stone-900 text-sm uppercase tracking-wider">Email</h4>
                  <p className="text-amber-700 font-semibold text-sm sm:text-base">
                    <a href="mailto:info@hotelrajdarbarayodhya.com" className="hover:underline">
                      info@hotelrajdarbarayodhya.com
                    </a>
                  </p>
                </div>
              </div>

              {/* Phone Reservation */}
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 rounded-xl bg-amber-600 flex items-center justify-center text-white shrink-0 shadow-md">
                  <Phone size={22} />
                </div>
                <div className="space-y-1">
                  <h4 className="font-bold text-stone-900 text-sm uppercase tracking-wider">Phone</h4>
                  <p className="text-amber-700 font-semibold text-sm sm:text-base flex flex-col">
                    <a href="tel:+919519102222" className="hover:underline">
                      +91 95191 02222
                    </a>
                    <a href="tel:+917309342222" className="hover:underline">
                      +91 73093 42222
                    </a>
                  </p>
                </div>
              </div>

              {/* Landmark Location */}
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 rounded-xl bg-amber-600 flex items-center justify-center text-white shrink-0 shadow-md">
                  <MapPin size={22} />
                </div>
                <div className="space-y-1 flex-1">
                  <h4 className="font-bold text-stone-900 text-sm uppercase tracking-wider">Location</h4>
                  <p className="text-stone-700 text-xs sm:text-sm leading-relaxed">
                    Behind Multi Level Parking, Near Ayodhya Dham Railway Station, Ayodhya, Uttar Pradesh 224123, India
                  </p>
                </div>
              </div>

              {/* Working Hours */}
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 rounded-xl bg-amber-600 flex items-center justify-center text-white shrink-0 shadow-md">
                  <Clock size={22} />
                </div>
                <div className="space-y-1">
                  <h4 className="font-bold text-stone-900 text-sm uppercase tracking-wider">Hours</h4>
                  <p className="text-stone-700 text-xs sm:text-sm">
                    Available 24/7 for your convenience
                  </p>
                </div>
              </div>

            </div>
          </div>

          {/* Right Column: Send Message Form */}
          <div className="lg:col-span-7">
            <div className="bg-white border border-stone-200/80 p-6 sm:p-8 rounded-3xl shadow-xl space-y-6">
              
              <div className="flex items-center space-x-3 pb-4 border-b border-stone-100">
                <MessageSquare className="text-stone-900" size={24} />
                <h3 className="font-display font-extrabold text-stone-900 text-xl uppercase tracking-wide">
                  Send us a Message
                </h3>
              </div>

              {isSubmitted ? (
                <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-6 text-center space-y-4 py-8 animate-fade-in">
                  <div className="w-14 h-14 bg-emerald-100 border border-emerald-300 rounded-full flex items-center justify-center text-emerald-600 mx-auto">
                    <Check size={28} strokeWidth={2.5} />
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-bold text-stone-900 text-lg uppercase tracking-wider">
                      Message Sent Successfully!
                    </h4>
                    <p className="text-stone-600 text-xs sm:text-sm max-w-sm mx-auto">
                      Thank you for contacting Hotel Raj Darbar. Our team will review your message and reply back within 2 hours.
                    </p>
                  </div>
                  <button 
                    onClick={() => setIsSubmitted(false)}
                    className="bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold py-2 px-6 rounded-lg text-xs uppercase tracking-wider transition-colors inline-block"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  
                  {/* Name field */}
                  <div className="space-y-1.5">
                    <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider">
                      Name
                    </label>
                    <input 
                      type="text" 
                      name="name"
                      required
                      value={formState.name}
                      onChange={handleInputChange}
                      className="w-full bg-[#FAF9F5] border border-stone-200 rounded-xl py-3 px-4 text-xs sm:text-sm text-stone-950 focus:outline-none focus:border-amber-500 transition-colors shadow-inner"
                      placeholder="Enter your name"
                    />
                  </div>

                  {/* Email field */}
                  <div className="space-y-1.5">
                    <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider">
                      Email
                    </label>
                    <input 
                      type="email" 
                      name="email"
                      required
                      value={formState.email}
                      onChange={handleInputChange}
                      className="w-full bg-[#FAF9F5] border border-stone-200 rounded-xl py-3 px-4 text-xs sm:text-sm text-stone-950 focus:outline-none focus:border-amber-500 transition-colors shadow-inner"
                      placeholder="Enter your email"
                    />
                  </div>

                  {/* Phone field */}
                  <div className="space-y-1.5">
                    <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider">
                      Phone
                    </label>
                    <input 
                      type="tel" 
                      name="phone"
                      required
                      value={formState.phone}
                      onChange={handleInputChange}
                      className="w-full bg-[#FAF9F5] border border-stone-200 rounded-xl py-3 px-4 text-xs sm:text-sm text-stone-950 focus:outline-none focus:border-amber-500 transition-colors shadow-inner"
                      placeholder="Enter your phone number"
                    />
                  </div>

                  {/* Subject field */}
                  <div className="space-y-1.5">
                    <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider">
                      Subject
                    </label>
                    <input 
                      type="text" 
                      name="subject"
                      required
                      value={formState.subject}
                      onChange={handleInputChange}
                      className="w-full bg-[#FAF9F5] border border-stone-200 rounded-xl py-3 px-4 text-xs sm:text-sm text-stone-950 focus:outline-none focus:border-amber-500 transition-colors shadow-inner"
                      placeholder="Enter message subject"
                    />
                  </div>

                  {/* Message field */}
                  <div className="space-y-1.5">
                    <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider">
                      Message
                    </label>
                    <textarea 
                      name="message"
                      required
                      rows={4}
                      value={formState.message}
                      onChange={handleInputChange}
                      className="w-full bg-[#FAF9F5] border border-stone-200 rounded-xl py-3 px-4 text-xs sm:text-sm text-stone-950 focus:outline-none focus:border-amber-500 transition-colors shadow-inner resize-none"
                      placeholder="Enter your message"
                    />
                  </div>

                  {/* Submit Button */}
                  <button 
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-[#C27D00] hover:bg-[#A36900] text-white font-bold py-3.5 rounded-xl text-xs sm:text-sm uppercase tracking-wider transition-all shadow-md hover:scale-[1.01] flex items-center justify-center space-x-2 disabled:opacity-75 cursor-pointer"
                  >
                    <span>{isSubmitting ? 'Sending...' : 'Send Message'}</span>
                    {!isSubmitting && <Send size={16} />}
                  </button>

                </form>
              )}

            </div>
          </div>

        </div>
      </div>

      {/* 3. Map Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20 space-y-8">
        
        <div className="space-y-2">
          <h2 className="font-display font-black text-2xl sm:text-3xl text-stone-900 uppercase tracking-tight">
            Visit Us On The Map
          </h2>
          <div className="w-16 h-1 bg-amber-500 rounded-full"></div>
        </div>

        {/* Map Box */}
        <div className="bg-white border border-stone-200/80 rounded-3xl overflow-hidden shadow-lg relative group">
          
          {/* Map Frame */}
          <div className="h-[400px] sm:h-[450px] w-full relative">
            <iframe 
              src="https://maps.google.com/maps?q=Hotel%20Raj%20Darbar%20Ayodhya%20Behind%20Multi%20Level%20Parking&t=&z=15&ie=UTF8&iwloc=&output=embed" 
              className="w-full h-full border-0 grayscale-[10%] contrast-[110%]"
              allowFullScreen={true}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Google Map Location of Hotel Raj Darbar"
            ></iframe>

            {/* "Open in Maps" button at the top left of the map frame */}
            <a 
              href="https://maps.google.com/?q=Hotel+Raj+Darbar+Ayodhya+Behind+Multi+Level+Parking"
              target="_blank"
              rel="noopener noreferrer"
              className="absolute top-4 left-4 bg-white/95 backdrop-blur-xs text-blue-600 font-bold px-4 py-2 rounded-lg text-xs sm:text-sm tracking-wide shadow-md border border-stone-200 hover:bg-stone-50 transition-all flex items-center space-x-1.5 z-10"
            >
              <span>Open in Maps</span>
              <ExternalLink size={14} />
            </a>
          </div>

          {/* Plus Code & Landmark Information Board */}
          <div className="bg-[#FAF9F5] border-t border-stone-200 p-6 sm:p-8 text-center space-y-3">
            <h3 className="font-bold text-amber-700 text-sm sm:text-base tracking-wide">
              Located Near Ayodhya Dham Railway Station
            </h3>
            <p className="text-stone-900 font-bold text-xs sm:text-sm uppercase tracking-wide">
              Behind Multi Level Parking, Near Ayodhya Dham Railway Station, Ayodhya, Uttar Pradesh 224123, India
            </p>
            <p className="text-stone-500 text-xs font-medium">
              We are conveniently located near the spiritual heart and key transport links of Ayodhya
            </p>
          </div>

        </div>

      </div>

    </div>
  );
}
