import React from 'react';
import { Room } from '../types';
import RoomCard from './RoomCard';

interface RoomsPageProps {
  rooms: Room[];
  filter: string;
  onFilterChange: (filter: string) => void;
  onBook: (roomId: string) => void;
}

export default function RoomsPage({ rooms, filter, onFilterChange, onBook }: RoomsPageProps) {
  // Filter rooms based on selection
  const filteredRooms = rooms.filter((room) => {
    if (filter === 'all') return true;
    // Map filter category IDs to room type matches
    return room.id.toLowerCase().includes(filter.toLowerCase());
  });

  const categories = [
    { id: 'all', label: 'All Rooms' },
    { id: 'executive', label: 'Executive' },
    { id: 'superior', label: 'Superior' },
    { id: 'signature', label: 'Signature' },
    { id: 'presidential', label: 'Presidential' },
    { id: 'family', label: 'Family' },
  ];

  return (
    <div className="bg-[#FAF9F5] min-h-screen">
      {/* 1. Header Banner - Dark Elegant Theme */}
      <div className="bg-neutral-900 pt-32 pb-20 px-4 text-center">
        <div className="max-w-4xl mx-auto space-y-4">
          <h1 className="font-display font-black text-white text-4xl sm:text-5xl md:text-6xl uppercase tracking-tight">
            Our Rooms & Suites
          </h1>
          <p className="text-stone-300 text-sm sm:text-base md:text-lg font-light tracking-wide max-w-2xl mx-auto">
            Discover our carefully curated collection of luxury accommodations
          </p>
        </div>
      </div>

      {/* 2. Filter Tabs & Rooms Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
        
        {/* Category Filters Row */}
        <div className="flex flex-wrap items-center justify-center gap-3 mb-16" id="rooms-page-filters">
          {categories.map((cat) => {
            const isActive = filter === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => onFilterChange(cat.id)}
                className={`px-6 py-2.5 rounded-lg text-xs sm:text-sm font-bold uppercase tracking-wider transition-all duration-300 border cursor-pointer ${
                  isActive
                    ? 'bg-[#d28a00] text-white border-[#d28a00] shadow-md'
                    : 'bg-white text-stone-800 border-stone-200 hover:border-stone-400 hover:bg-stone-50'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>

        {/* Rooms Cards Grid */}
        {filteredRooms.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 sm:gap-10" id="rooms-grid">
            {filteredRooms.map((room) => (
              <RoomCard key={room.id} room={room} onBook={onBook} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-white rounded-3xl border border-stone-200 max-w-xl mx-auto">
            <p className="text-stone-500 font-medium text-lg">No accommodations match your selection.</p>
            <button
              onClick={() => onFilterChange('all')}
              className="mt-4 text-[#d28a00] hover:text-amber-600 font-bold uppercase tracking-wider text-sm transition-colors cursor-pointer"
            >
              Show All Rooms
            </button>
          </div>
        )}

      </div>
    </div>
  );
}
