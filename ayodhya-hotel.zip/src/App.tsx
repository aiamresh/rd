import React, { useState, useEffect, useRef, FormEvent } from 'react';
import {
  Calendar,
  ChevronLeft,
  ChevronRight,
  Menu,
  X,
  MapPin,
  Phone,
  Mail,
  Clock,
  UtensilsCrossed,
  Compass,
  Wifi,
  Car,
  Award,
  Plane,
  Sparkles,
  Star,
  Check,
  ExternalLink,
  Users,
  ArrowRight,
  Info,
  Gift,
  Building,
  Map,
  ShieldCheck,
  Send,
  Bed,
  CheckSquare,
  Bookmark
} from 'lucide-react';
import { HOTEL_INFO, ROOMS, AMENITIES, TESTIMONIALS, GALLERY_ITEMS } from './data';
import { Room, BookingDetails } from './types';
import RoomsPage from './components/RoomsPage';
import AboutPage from './components/AboutPage';
import DiningPage from './components/DiningPage';
import ServicesPage from './components/ServicesPage';
import ContactPage from './components/ContactPage';

export default function App() {
  // Navigation & UI States
  const [activeSection, setActiveSection] = useState('home');
  const [currentView, setCurrentView] = useState<'home' | 'rooms' | 'about' | 'dining' | 'services' | 'contact'>('home');
  const [roomsFilter, setRoomsFilter] = useState<string>('all');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  // Hero Slider State
  const [currentSlide, setCurrentSlide] = useState(0);
  const slides = [
    {
      image: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&q=80&w=1600',
      title: 'Welcome to Luxury',
      subtitle: 'Experience world-class hospitality',
      tagline: '✨ Divine Heritage Hospitality'
    },
    {
      image: 'https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&q=80&w=1600',
      title: 'Surrounded by natural beauty',
      subtitle: 'A serene oasis of spirituality and peace',
      tagline: '🌿 Divine Gardens & Courtyards'
    },
    {
      image: 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&q=80&w=1600',
      title: 'Majestic Royal Suites',
      subtitle: 'Divine comfort tailored for your pilgrimage',
      tagline: '👑 Heritage Luxury Defined'
    }
  ];

  // Gallery Filter State
  const [selectedGalleryCategory, setSelectedGalleryCategory] = useState<'all' | 'rooms' | 'dining' | 'exterior' | 'spiritual'>('all');
  const [activeLightbox, setActiveLightbox] = useState<string | null>(null);

  // Booking states
  const [checkIn, setCheckIn] = useState('2026-07-21');
  const [checkOut, setCheckOut] = useState('2026-07-24');
  const [guestsCount, setGuestsCount] = useState('2');
  const [selectedRoomType, setSelectedRoomType] = useState('all');
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState(false);
  const [bookingForm, setBookingForm] = useState({
    name: '',
    email: '',
    phone: '',
    specialRequests: ''
  });
  const [confirmedBookingDetails, setConfirmedBookingDetails] = useState<any | null>(null);

  // Quick Notification/Feedback State
  const [contactSuccess, setContactSuccess] = useState(false);
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });

  // Autoplay Slider effect
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  // Listen to scroll to apply style to sticky header
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Set active section on scroll
  useEffect(() => {
    const handleScrollActiveSection = () => {
      if (currentView !== 'home') return;
      const sections = ['home', 'rooms', 'about', 'services', 'dining', 'gallery', 'contact'];
      const scrollPosition = window.scrollY + 120;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const top = element.offsetTop;
          const height = element.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };
    window.addEventListener('scroll', handleScrollActiveSection);
    return () => window.removeEventListener('scroll', handleScrollActiveSection);
  }, [currentView]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  // Helper to scroll to section
  const scrollToSection = (id: string) => {
    setIsMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
      setActiveSection(id);
    }
  };

  // Unified navigation click handler supporting standalone Rooms and About pages
  const handleNavClick = (sectionId: string) => {
    setIsMobileMenuOpen(false);
    if (sectionId === 'rooms') {
      setCurrentView('rooms');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      setActiveSection('rooms');
    } else if (sectionId === 'about') {
      setCurrentView('about');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      setActiveSection('about');
    } else if (sectionId === 'dining') {
      setCurrentView('dining');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      setActiveSection('dining');
    } else if (sectionId === 'services') {
      setCurrentView('services');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      setActiveSection('services');
    } else if (sectionId === 'contact') {
      setCurrentView('contact');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      setActiveSection('contact');
    } else {
      setCurrentView('home');
      setActiveSection(sectionId);
      // Wait for layout update before scrolling to the element
      setTimeout(() => {
        const element = document.getElementById(sectionId);
        if (element) {
          const headerOffset = 80;
          const elementPosition = element.getBoundingClientRect().top;
          const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
          window.scrollTo({
            top: offsetPosition,
            behavior: 'smooth'
          });
        } else {
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
      }, 100);
    }
  };

  // Handle open booking modal with optional room default
  const openBookingModal = (roomType?: string) => {
    if (roomType) {
      setSelectedRoomType(roomType);
    }
    setIsBookingModalOpen(true);
    setBookingSuccess(false);
  };

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const selectedRoom = ROOMS.find(r => r.id === selectedRoomType) || ROOMS[0];
    const days = Math.max(1, Math.ceil((new Date(checkOut).getTime() - new Date(checkIn).getTime()) / (1000 * 60 * 60 * 24))) || 1;
    const basePrice = selectedRoom.price * days;
    const tax = Math.round(basePrice * 0.12); // 12% GST
    const serviceCharge = 500;
    const totalPrice = basePrice + tax + serviceCharge;

    const details = {
      bookingId: 'AYODHYA-' + Math.floor(100000 + Math.random() * 900000),
      checkIn,
      checkOut,
      guests: guestsCount,
      roomName: selectedRoom.name,
      roomPrice: selectedRoom.price,
      days,
      basePrice,
      tax,
      serviceCharge,
      totalPrice,
      customerName: bookingForm.name,
      customerEmail: bookingForm.email,
      customerPhone: bookingForm.phone,
      specialRequests: bookingForm.specialRequests
    };

    setConfirmedBookingDetails(details);
    setBookingSuccess(true);
    
    // Clear form
    setBookingForm({
      name: '',
      email: '',
      phone: '',
      specialRequests: ''
    });
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setContactSuccess(true);
    setTimeout(() => {
      setContactSuccess(false);
      setContactForm({
        name: '',
        email: '',
        phone: '',
        subject: '',
        message: ''
      });
    }, 5000);
  };

  return (
    <div className="min-h-screen bg-[#FAF9F5] text-stone-800 font-sans selection:bg-amber-600 selection:text-white">
      
      {/* 1. Navigation Header - Clean glassmorphism sticky header */}
      <nav id="navbar" className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-neutral-900/95 backdrop-blur-md py-3 shadow-lg border-b border-amber-900/20' 
          : 'bg-neutral-900/80 backdrop-blur-xs py-5'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            
            {/* Logo on Left */}
            <div 
              onClick={() => handleNavClick('home')} 
              className="flex items-center space-x-3 cursor-pointer group"
              id="logo-container"
            >
              <div className="relative w-12 h-12 rounded-full border-2 border-amber-500 flex items-center justify-center bg-neutral-900/50 shadow-inner group-hover:scale-105 transition-transform duration-300">
                <span className="font-display font-bold text-amber-500 text-lg leading-none">RD</span>
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-amber-500 rounded-full animate-ping opacity-25"></div>
              </div>
              <div className="flex flex-col">
                <span className="font-display font-extrabold text-amber-400 text-lg sm:text-xl tracking-wider leading-none uppercase">
                  Raj Darbar
                </span>
                <span className="text-[10px] text-stone-300 uppercase tracking-widest mt-1">
                  Hotel & Restaurant
                </span>
              </div>
            </div>

            {/* Desktop Center Navigation Links */}
            <div className="hidden lg:flex items-center space-x-7" id="desktop-menu">
              <button 
                id="nav-home"
                onClick={() => handleNavClick('home')} 
                className={`font-medium text-sm tracking-widest uppercase transition-colors duration-200 cursor-pointer ${
                  currentView === 'home' && activeSection === 'home' ? 'text-amber-400 border-b border-amber-400' : 'text-stone-200 hover:text-amber-300'
                }`}
              >
                Home
              </button>
              <button 
                id="nav-rooms"
                onClick={() => handleNavClick('rooms')} 
                className={`font-medium text-sm tracking-widest uppercase transition-colors duration-200 cursor-pointer ${
                  currentView === 'rooms' ? 'text-amber-400 border-b border-amber-400' : 'text-stone-200 hover:text-amber-300'
                }`}
              >
                Rooms
              </button>
              <button 
                id="nav-about"
                onClick={() => handleNavClick('about')} 
                className={`font-medium text-sm tracking-widest uppercase transition-colors duration-200 cursor-pointer ${
                  currentView === 'about' ? 'text-amber-400 border-b border-amber-400' : 'text-stone-200 hover:text-amber-300'
                }`}
              >
                About
              </button>
              <button 
                id="nav-services"
                onClick={() => handleNavClick('services')} 
                className={`font-medium text-sm tracking-widest uppercase transition-colors duration-200 cursor-pointer ${
                  currentView === 'services' ? 'text-amber-400 border-b border-amber-400' : 'text-stone-200 hover:text-amber-300'
                }`}
              >
                Services
              </button>
              
              {/* Dining Link with red DINE badge */}
              <div className="relative group cursor-pointer" id="nav-dining-container">
                <button 
                  id="nav-dining"
                  onClick={() => handleNavClick('dining')} 
                  className={`font-medium text-sm tracking-widest uppercase transition-all duration-200 cursor-pointer flex items-center ${
                    currentView === 'dining' ? 'text-amber-400 border-b border-amber-400' : 'text-stone-200 hover:text-amber-300'
                  }`}
                >
                  La'Pulse Dine
                </button>
                <span className="absolute -top-4 -right-4 bg-red-600 text-[9px] font-bold text-white px-1.5 py-0.5 rounded-full uppercase tracking-tighter animate-pulse shadow-md z-10">
                  DINE
                </span>
              </div>

              <button 
                id="nav-gallery"
                onClick={() => handleNavClick('gallery')} 
                className={`font-medium text-sm tracking-widest uppercase transition-colors duration-200 cursor-pointer ${
                  currentView === 'home' && activeSection === 'gallery' ? 'text-amber-400 border-b border-amber-400' : 'text-stone-200 hover:text-amber-300'
                }`}
              >
                Gallery
              </button>
              <button 
                id="nav-contact"
                onClick={() => handleNavClick('contact')} 
                className={`font-medium text-sm tracking-widest uppercase transition-colors duration-200 cursor-pointer ${
                  currentView === 'contact' ? 'text-amber-400 border-b border-amber-400' : 'text-stone-200 hover:text-amber-300'
                }`}
              >
                Contact
              </button>
            </div>

            {/* Desktop Right Button */}
            <div className="hidden lg:block">
              <button 
                id="header-book-now"
                onClick={() => openBookingModal()}
                className="bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold px-6 py-2.5 rounded-full text-sm uppercase tracking-wider transition-all duration-300 transform hover:scale-105 shadow-md border border-amber-400/30 cursor-pointer"
              >
                Book Now
              </button>
            </div>

            {/* Mobile menu button */}
            <div className="flex lg:hidden">
              <button
                id="mobile-menu-toggle"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="text-stone-200 hover:text-amber-400 focus:outline-none p-2 rounded-md"
              >
                {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
              </button>
            </div>

          </div>
        </div>

        {/* Mobile menu navigation drop */}
        {isMobileMenuOpen && (
          <div className="lg:hidden bg-neutral-900 border-t border-amber-900/20 px-4 pt-4 pb-6 space-y-3 transition-all duration-300 shadow-xl" id="mobile-menu">
            <button 
              id="mob-nav-home"
              onClick={() => handleNavClick('home')} 
              className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-stone-100 hover:bg-amber-900/20 hover:text-amber-400"
            >
              Home
            </button>
            <button 
              id="mob-nav-rooms"
              onClick={() => handleNavClick('rooms')} 
              className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-stone-100 hover:bg-amber-900/20 hover:text-amber-400"
            >
              Rooms
            </button>
            <button 
              id="mob-nav-about"
              onClick={() => handleNavClick('about')} 
              className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-stone-100 hover:bg-amber-900/20 hover:text-amber-400"
            >
              About
            </button>
            <button 
              id="mob-nav-services"
              onClick={() => handleNavClick('services')} 
              className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-stone-100 hover:bg-amber-900/20 hover:text-amber-400"
            >
              Services
            </button>
            <button 
              id="mob-nav-dining"
              onClick={() => handleNavClick('dining')} 
              className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-amber-400 hover:bg-amber-900/20 flex items-center justify-between"
            >
              <span>La'Pulse Dine</span>
              <span className="bg-red-600 text-[8px] font-bold text-white px-2 py-0.5 rounded-full uppercase tracking-wider animate-pulse">
                DINE
              </span>
            </button>
            <button 
              id="mob-nav-gallery"
              onClick={() => handleNavClick('gallery')} 
              className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-stone-100 hover:bg-amber-900/20 hover:text-amber-400"
            >
              Gallery
            </button>
            <button 
              id="mob-nav-contact"
              onClick={() => handleNavClick('contact')} 
              className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-stone-100 hover:bg-amber-900/20 hover:text-amber-400"
            >
              Contact
            </button>
            <div className="pt-4 border-t border-neutral-800">
              <button 
                id="mob-nav-book"
                onClick={() => { setIsMobileMenuOpen(false); openBookingModal(); }}
                className="w-full bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold py-3 px-4 rounded-full text-center text-sm uppercase tracking-wider shadow-lg transition-colors cursor-pointer"
              >
                Book Your Stay
              </button>
            </div>
          </div>
        )}
      </nav>

      {currentView === 'home' ? (
        <>
          {/* 2. Hero Image Slider with Overlay Text & Arrows */}
          <section id="home" className="relative h-[100vh] sm:h-[95vh] w-full overflow-hidden bg-stone-950">
        
        {/* Slides Container */}
        <div className="relative h-full w-full">
          {slides.map((slide, idx) => (
            <div
              key={idx}
              id={`hero-slide-${idx}`}
              className={`absolute inset-0 h-full w-full transition-opacity duration-1000 ease-in-out ${
                idx === currentSlide ? 'opacity-100 z-10 scale-100' : 'opacity-0 z-0 scale-105'
              } transition-transform duration-[6000ms]`}
            >
              {/* Overlay shadow tint to match screenshots */}
              <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/45 to-black/70 z-10"></div>
              
              <img
                src={slide.image}
                alt={slide.title}
                className="h-full w-full object-cover object-center"
              />
              
              {/* Content Centered exactly like screenshots */}
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-4 z-20">
                <span className="text-amber-400 font-bold uppercase tracking-[0.25em] text-xs sm:text-sm mb-4 animate-fade-in-down drop-shadow">
                  {slide.tagline}
                </span>
                <h1 className="font-display font-extrabold text-white text-4xl sm:text-6xl md:text-7xl lg:text-8xl tracking-tight mb-4 drop-shadow-md">
                  {slide.title}
                </h1>
                <p className="text-stone-200 text-lg sm:text-xl md:text-2xl font-light max-w-2xl mx-auto mb-10 drop-shadow">
                  {slide.subtitle}
                </p>
                <button
                  id={`hero-cta-btn-${idx}`}
                  onClick={() => openBookingModal()}
                  className="bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold px-8 py-3.5 rounded-md text-sm uppercase tracking-widest transition-all duration-300 transform hover:scale-105 shadow-xl hover:shadow-amber-500/20 cursor-pointer"
                >
                  Book Your Stay
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Left Arrow Button */}
        <button
          id="hero-prev-btn"
          onClick={prevSlide}
          className="absolute left-4 sm:left-6 top-1/2 -translate-y-1/2 z-30 bg-neutral-900/40 hover:bg-amber-500 hover:text-stone-950 text-white w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center border border-white/20 hover:border-amber-500 transition-all duration-300 shadow-lg cursor-pointer"
        >
          <ChevronLeft size={24} />
        </button>

        {/* Right Arrow Button */}
        <button
          id="hero-next-btn"
          onClick={nextSlide}
          className="absolute right-4 sm:right-6 top-1/2 -translate-y-1/2 z-30 bg-neutral-900/40 hover:bg-amber-500 hover:text-stone-950 text-white w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center border border-white/20 hover:border-amber-500 transition-all duration-300 shadow-lg cursor-pointer"
        >
          <ChevronRight size={24} />
        </button>

        {/* Slide Indicator Dots */}
        <div className="absolute bottom-12 sm:bottom-16 left-1/2 -translate-x-1/2 z-30 flex space-x-3">
          {slides.map((_, idx) => (
            <button
              key={idx}
              id={`hero-dot-${idx}`}
              onClick={() => setCurrentSlide(idx)}
              className={`h-2 rounded-full transition-all duration-500 ${
                idx === currentSlide ? 'w-8 bg-amber-500' : 'w-2 bg-white/40'
              }`}
              aria-label={`Go to slide ${idx + 1}`}
            ></button>
          ))}
        </div>

      </section>

      {/* 3. Floating Quick Booking / Check Availability Bar */}
      <div className="relative z-30 -mt-10 sm:-mt-16 max-w-6xl mx-auto px-4" id="availability-bar-section">
        <div className="bg-neutral-950 border border-amber-900/30 rounded-2xl p-4 sm:p-6 shadow-2xl">
          
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
            
            {/* Check-In */}
            <div className="md:col-span-3">
              <label className="block text-amber-500 text-[10px] uppercase font-bold tracking-widest mb-1.5 flex items-center">
                <Calendar size={12} className="mr-1 text-amber-500" />
                Check In
              </label>
              <div className="relative">
                <input
                  type="date"
                  value={checkIn}
                  onChange={(e) => setCheckIn(e.target.value)}
                  min="2026-07-21"
                  className="w-full bg-stone-900 text-white border border-stone-800 rounded-lg py-2.5 px-3 text-sm focus:outline-none focus:border-amber-500 transition-colors"
                />
              </div>
            </div>

            {/* Check-Out */}
            <div className="md:col-span-3">
              <label className="block text-amber-500 text-[10px] uppercase font-bold tracking-widest mb-1.5 flex items-center">
                <Calendar size={12} className="mr-1 text-amber-500" />
                Check Out
              </label>
              <div className="relative">
                <input
                  type="date"
                  value={checkOut}
                  onChange={(e) => setCheckOut(e.target.value)}
                  min={checkIn}
                  className="w-full bg-stone-900 text-white border border-stone-800 rounded-lg py-2.5 px-3 text-sm focus:outline-none focus:border-amber-500 transition-colors"
                />
              </div>
            </div>

            {/* Guests */}
            <div className="md:col-span-2">
              <label className="block text-amber-500 text-[10px] uppercase font-bold tracking-widest mb-1.5 flex items-center">
                <Users size={12} className="mr-1 text-amber-500" />
                Rooms / Guests
              </label>
              <select
                value={guestsCount}
                onChange={(e) => setGuestsCount(e.target.value)}
                className="w-full bg-stone-900 text-white border border-stone-800 rounded-lg py-2.5 px-3 text-sm focus:outline-none focus:border-amber-500 transition-colors appearance-none cursor-pointer"
              >
                <option value="1">1 Guest</option>
                <option value="2">2 Guests</option>
                <option value="3">3 Guests</option>
                <option value="4">4 Guests</option>
                <option value="5">5+ Guests (Family)</option>
              </select>
            </div>

            {/* Room Type */}
            <div className="md:col-span-2">
              <label className="block text-amber-500 text-[10px] uppercase font-bold tracking-widest mb-1.5 flex items-center">
                <Bed size={12} className="mr-1 text-amber-500" />
                Room Type
              </label>
              <select
                value={selectedRoomType}
                onChange={(e) => setSelectedRoomType(e.target.value)}
                className="w-full bg-stone-900 text-white border border-stone-800 rounded-lg py-2.5 px-3 text-sm focus:outline-none focus:border-amber-500 transition-colors appearance-none cursor-pointer"
              >
                <option value="all">Any Room</option>
                {ROOMS.map((room) => (
                  <option key={room.id} value={room.id}>
                    {room.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Submit Button */}
            <div className="md:col-span-2">
              <button
                id="check-availability-btn"
                onClick={() => openBookingModal()}
                className="w-full bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold py-3 px-4 rounded-lg text-xs uppercase tracking-wider transition-colors duration-300 cursor-pointer text-center"
              >
                Check Availability
              </button>
            </div>

          </div>

        </div>
      </div>

      {/* 4. Welcome / Overview Section */}
      <section id="about" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto scroll-mt-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center space-x-2 bg-amber-100 text-amber-800 px-4 py-1.5 rounded-full text-xs font-semibold uppercase tracking-wider mb-4 border border-amber-200">
            <Sparkles size={14} className="animate-spin text-amber-600" />
            <span>Welcome to Luxury</span>
          </div>
          <h2 className="font-display font-extrabold text-stone-900 text-3xl sm:text-5xl tracking-tight mb-6 uppercase">
            Hotel Raj Darbar
          </h2>
          <p className="text-stone-600 text-lg leading-relaxed mb-4">
            Strategically located behind the multi-level parking near the Ayodhya Dham Railway Station, <strong className="text-amber-700 font-semibold">Hotel Raj Darbar</strong> is a premier hotel designed to give tourists, families, and leisure travelers premium luxury combined with warm royal hospitality.
          </p>
          <div className="h-0.5 w-24 bg-amber-500 mx-auto my-6"></div>
          <p className="text-stone-500 text-md leading-relaxed">
            Just minutes from the divine gateway of Shri Ram Janmabhoomi Temple, our hotel provides unmatched comfort, premium AC rooms, delectable fine dining, and modern amenities for a perfect stay in Ayodhya.
          </p>
        </div>

        {/* Grid Highlights */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12" id="about-highlights">
          
          {/* Card 1 */}
          <div className="bg-white rounded-2xl p-8 border border-stone-200/60 shadow-md hover:shadow-xl transition-all duration-300 group hover:-translate-y-1">
            <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 mb-6 group-hover:bg-amber-500 group-hover:text-stone-950 transition-colors duration-300">
              <Building size={28} />
            </div>
            <h3 className="font-display font-bold text-xl text-stone-900 mb-3 uppercase tracking-wide">
              Divine Accommodations
            </h3>
            <p className="text-stone-600 text-sm leading-relaxed">
              50 masterfully furnished, soundproofed hotel rooms and suites decorated with fine wooden carpentry, luxury mattresses, and stunning panoramic views of historical temples.
            </p>
          </div>

          {/* Card 2 */}
          <div className="bg-white rounded-2xl p-8 border border-stone-200/60 shadow-md hover:shadow-xl transition-all duration-300 group hover:-translate-y-1">
            <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 mb-6 group-hover:bg-amber-500 group-hover:text-stone-950 transition-colors duration-300">
              <UtensilsCrossed size={28} />
            </div>
            <h3 className="font-display font-bold text-xl text-stone-900 mb-3 uppercase tracking-wide">
              La'Pulse Restaurant
            </h3>
            <p className="text-stone-600 text-sm leading-relaxed">
              Our premier 100% pure vegetarian, multi-cuisine sanctuary serving gourmet Satvik and traditional Indian cuisine prepared with pure ingredients and absolute devotion.
            </p>
          </div>

          {/* Card 3 */}
          <div className="bg-white rounded-2xl p-8 border border-stone-200/60 shadow-md hover:shadow-xl transition-all duration-300 group hover:-translate-y-1">
            <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 mb-6 group-hover:bg-amber-500 group-hover:text-stone-950 transition-colors duration-300">
              <Compass size={28} />
            </div>
            <h3 className="font-display font-bold text-xl text-stone-900 mb-3 uppercase tracking-wide">
              Guided Sacred Journeys
            </h3>
            <p className="text-stone-600 text-sm leading-relaxed">
              Our expert travel curators assist in coordinating effortless premium Darshans, local expert-guided tours, evening Sarayu Aarti boat rides, and hassle-free transit.
            </p>
          </div>

        </div>
      </section>

      {/* 5. Rooms Section */}
      <section id="rooms" className="py-20 bg-stone-100 scroll-mt-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-amber-600 text-xs font-bold uppercase tracking-widest block mb-2">Our Sanctuary</span>
            <h2 className="font-display font-extrabold text-stone-900 text-3xl sm:text-5xl uppercase tracking-tight">
              Divine Rooms & Suites
            </h2>
            <p className="text-stone-500 text-md mt-4">
              Rest your mind, body, and spirit in beautifully curated accommodations outfitted with modern amenities and classic heritage craftsmanship.
            </p>
          </div>

          {/* Rooms Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" id="rooms-list-grid">
            {ROOMS.map((room) => (
              <div 
                key={room.id}
                id={`room-card-${room.id}`}
                className="bg-white rounded-2xl overflow-hidden border border-stone-200 shadow-lg hover:shadow-2xl transition-all duration-500 flex flex-col group"
              >
                {/* Image & Price Overlay */}
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={room.image}
                    alt={room.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                  
                  {/* Price Tag */}
                  <div className="absolute bottom-4 left-4 text-white">
                    <span className="text-stone-300 text-xs uppercase tracking-wider block">Starting from</span>
                    <span className="font-display font-bold text-2xl text-amber-400">₹{room.price.toLocaleString()}</span>
                    <span className="text-stone-300 text-xs"> / Night</span>
                  </div>

                  {/* View Tag */}
                  <div className="absolute top-4 right-4 bg-stone-900/80 backdrop-blur-md border border-amber-500/30 text-amber-400 px-3 py-1 rounded-full text-xs font-medium uppercase tracking-wider">
                    {room.view}
                  </div>
                </div>

                {/* Card Content */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="font-display font-bold text-xl text-stone-900 uppercase tracking-wide group-hover:text-amber-600 transition-colors">
                      {room.name}
                    </h3>
                    <p className="text-amber-700 text-xs italic font-medium mt-1 mb-3">
                      "{room.tagline}"
                    </p>
                    <p className="text-stone-600 text-sm leading-relaxed mb-6">
                      {room.description.length > 140 ? `${room.description.slice(0, 140)}...` : room.description}
                    </p>

                    {/* Room details specs */}
                    <div className="grid grid-cols-2 gap-y-2 gap-x-4 py-4 border-t border-b border-stone-100 text-xs text-stone-600 mb-6">
                      <div className="flex items-center">
                        <span className="font-bold text-stone-800 mr-1">Size:</span> {room.size}
                      </div>
                      <div className="flex items-center">
                        <span className="font-bold text-stone-800 mr-1">Bed:</span> {room.bedType}
                      </div>
                      <div className="flex items-center col-span-2">
                        <span className="font-bold text-stone-800 mr-1">Capacity:</span> {room.capacity}
                      </div>
                    </div>

                    {/* Quick highlight amenities */}
                    <div className="mb-6">
                      <span className="text-stone-500 text-[10px] uppercase font-bold tracking-wider block mb-2">Key Amenities Included:</span>
                      <div className="flex flex-wrap gap-1.5">
                        {room.amenities.slice(0, 4).map((amenity, idx) => (
                          <span key={idx} className="bg-stone-100 text-stone-700 text-[10px] font-semibold px-2.5 py-1 rounded-md flex items-center">
                            <Check size={10} className="text-amber-600 mr-1" />
                            {amenity}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center justify-between gap-3 pt-4 border-t border-stone-100">
                    <button
                      id={`book-room-btn-${room.id}`}
                      onClick={() => openBookingModal(room.id)}
                      className="flex-1 bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold py-3 px-4 rounded-lg text-xs uppercase tracking-wider text-center transition-colors duration-300 cursor-pointer"
                    >
                      Book This Room
                    </button>
                    <button
                      id={`view-details-btn-${room.id}`}
                      onClick={() => openBookingModal(room.id)}
                      className="bg-stone-100 hover:bg-stone-200 text-stone-800 font-semibold p-3 rounded-lg text-xs transition-colors duration-300 cursor-pointer"
                      title="View Full Details"
                    >
                      <Info size={16} />
                    </button>
                  </div>

                </div>

              </div>
            ))}
          </div>

        </div>
      </section>

      {/* 6. La'Pulse Dine Restaurant Section */}
      <section id="dining" className="py-24 bg-stone-900 text-white relative overflow-hidden scroll-mt-10">
        
        {/* Background ambient lighting overlay */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-amber-500/10 via-transparent to-transparent z-0"></div>
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-black to-transparent z-0"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Column: Text description */}
            <div className="lg:col-span-5 space-y-6">
              <div className="inline-flex items-center space-x-2 bg-red-600/20 text-red-400 border border-red-500/30 px-3.5 py-1 rounded-full text-xs font-semibold uppercase tracking-wider">
                <UtensilsCrossed size={12} />
                <span>Premier Dining</span>
              </div>
              
              <h2 className="font-display font-black text-4xl sm:text-5xl text-white tracking-tight uppercase">
                LA'PULSE DINE
              </h2>
              
              <h3 className="text-amber-400 font-display text-xl italic font-medium leading-relaxed">
                "Where taste meets holy devotion - 100% Pure Vegetarian & Satvik multi-cuisine fine dining."
              </h3>
              
              <p className="text-stone-300 text-sm leading-relaxed">
                Step into a world of exquisite traditional aromas and world-class culinary expertise. <strong className="text-white font-semibold">La'Pulse Dine</strong> is our premier fine dining establishment designed to serve our guests with authentic recipes cooked with strict standards of purity and premium local ingredients.
              </p>

              <div className="border-t border-stone-800 pt-6 space-y-4">
                <div className="flex items-start">
                  <div className="w-6 h-6 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mt-1 mr-3 shrink-0">
                    <Check size={14} />
                  </div>
                  <div>
                    <h4 className="font-bold text-stone-100 text-sm">Gourmet Satvik Delicacies</h4>
                    <p className="text-stone-400 text-xs">Carefully crafted recipes free of onion and garlic, keeping in touch with the spiritual essence of Ayodhya Dham.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-6 h-6 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mt-1 mr-3 shrink-0">
                    <Check size={14} />
                  </div>
                  <div>
                    <h4 className="font-bold text-stone-100 text-sm">Traditional Copperware Table Service</h4>
                    <p className="text-stone-400 text-xs">Indulge in our signature royal thalis served in heritage brass and copperware, celebrating royal Awadhi culture.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-6 h-6 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mt-1 mr-3 shrink-0">
                    <Check size={14} />
                  </div>
                  <div>
                    <h4 className="font-bold text-stone-100 text-sm">Universal Multi-Cuisine Menu</h4>
                    <p className="text-stone-400 text-xs">Offering customized global cuisines including Punjabi, South Indian, Chinese, Continental, and custom child-friendly meals.</p>
                  </div>
                </div>
              </div>

              <div className="pt-4 flex flex-wrap gap-4">
                <button
                  id="book-table-btn"
                  onClick={() => openBookingModal()}
                  className="bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold px-6 py-3 rounded-lg text-xs uppercase tracking-wider transition-colors duration-300 cursor-pointer"
                >
                  Reserve A Table
                </button>
                <button
                  id="view-menu-btn"
                  onClick={() => scrollToSection('contact')}
                  className="bg-stone-800 hover:bg-stone-700 text-stone-100 font-bold px-6 py-3 rounded-lg text-xs uppercase tracking-wider border border-stone-700 transition-colors duration-300 cursor-pointer"
                >
                  Contact Restaurant
                </button>
              </div>

            </div>

            {/* Right Column: Beautiful photo cards Grid */}
            <div className="lg:col-span-7 grid grid-cols-2 gap-4 sm:gap-6">
              
              <div className="space-y-4 sm:space-y-6">
                <div className="rounded-2xl overflow-hidden h-48 sm:h-60 shadow-xl border border-stone-800 relative group">
                  <img
                    src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&q=80&w=600"
                    alt="Dining Hall"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-black/45 flex items-end p-4">
                    <span className="text-white font-display font-bold text-sm uppercase tracking-wider">Luxurious Ambience</span>
                  </div>
                </div>

                <div className="rounded-2xl overflow-hidden h-40 sm:h-48 shadow-xl border border-stone-800 relative group">
                  <img
                    src="https://images.unsplash.com/photo-1601050690597-df056fb4ce78?auto=format&fit=crop&q=80&w=600"
                    alt="Royal Thali"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-black/45 flex items-end p-4">
                    <span className="text-white font-display font-bold text-sm uppercase tracking-wider">Satvik Royal Thali</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4 sm:space-y-6 pt-6 sm:pt-10">
                <div className="rounded-2xl overflow-hidden h-40 sm:h-48 shadow-xl border border-stone-800 relative group">
                  <img
                    src="https://images.unsplash.com/photo-1626074353765-517a681e40be?auto=format&fit=crop&q=80&w=600"
                    alt="Dessert"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-black/45 flex items-end p-4">
                    <span className="text-white font-display font-bold text-sm uppercase tracking-wider">Divine Desserts</span>
                  </div>
                </div>

                <div className="rounded-2xl overflow-hidden h-48 sm:h-60 shadow-xl border border-stone-800 relative group">
                  <img
                    src="https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80&w=600"
                    alt="Chef Cooking"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-black/45 flex items-end p-4">
                    <span className="text-white font-display font-bold text-sm uppercase tracking-wider">Hygienic Kitchens</span>
                  </div>
                </div>
              </div>

            </div>

          </div>

        </div>
      </section>

      {/* 7. Services & Amenities Section */}
      <section id="services" className="py-24 bg-stone-50 scroll-mt-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto mb-20">
            <span className="text-amber-600 text-xs font-bold uppercase tracking-widest block mb-2">Our Offerings</span>
            <h2 className="font-display font-extrabold text-stone-900 text-3xl sm:text-5xl uppercase tracking-tight">
              World-Class Amenities
            </h2>
            <div className="h-0.5 w-16 bg-amber-500 mx-auto mt-4 mb-6"></div>
            <p className="text-stone-500 text-md">
              We leave no stone unturned to ensure your family's safety, spiritual fulfillment, and absolute luxury are guaranteed during your stay in Ayodhya.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8" id="amenities-grid">
            {AMENITIES.map((amenity, idx) => {
              // Dynamically map icons to prevent errors
              let IconComponent = Sparkles;
              if (amenity.icon === 'UtensilsCrossed') IconComponent = UtensilsCrossed;
              else if (amenity.icon === 'Compass') IconComponent = Compass;
              else if (amenity.icon === 'Clock') IconComponent = Clock;
              else if (amenity.icon === 'Wifi') IconComponent = Wifi;
              else if (amenity.icon === 'Car') IconComponent = Car;
              else if (amenity.icon === 'Award') IconComponent = Award;
              else if (amenity.icon === 'Plane') IconComponent = Plane;
              else if (amenity.icon === 'Sparkles') IconComponent = Sparkles;

              return (
                <div 
                  key={idx}
                  id={`amenity-card-${idx}`}
                  className="bg-white rounded-2xl p-6 border border-stone-200/60 shadow-md hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    <div className="w-12 h-12 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600">
                      <IconComponent size={24} />
                    </div>
                    <h3 className="font-display font-bold text-lg text-stone-900 uppercase tracking-wide">
                      {amenity.title}
                    </h3>
                    <p className="text-stone-600 text-xs leading-relaxed">
                      {amenity.desc}
                    </p>
                  </div>
                  <div className="pt-4 border-t border-stone-50 mt-4 flex items-center text-amber-700 text-[10px] uppercase font-bold tracking-wider">
                    <span>Included Free</span>
                    <Check size={12} className="ml-1" />
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* 8. Gallery Section with lightbox */}
      <section id="gallery" className="py-24 bg-white scroll-mt-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
            <div className="max-w-xl text-left">
              <span className="text-amber-600 text-xs font-bold uppercase tracking-widest block mb-2">Visual Tour</span>
              <h2 className="font-display font-extrabold text-stone-900 text-3xl sm:text-4xl uppercase tracking-tight">
                Our Gallery
              </h2>
              <p className="text-stone-500 text-sm mt-2">
                Browse through high-resolution visuals of our luxurious heritage accommodations, multi-cuisine dining hall, spiritual gardens, and holy landmarks.
              </p>
            </div>

            {/* Category Filter Pills */}
            <div className="flex flex-wrap gap-2 mt-6 md:mt-0" id="gallery-filters">
              {(['all', 'rooms', 'dining', 'exterior', 'spiritual'] as const).map((category) => (
                <button
                  key={category}
                  id={`gallery-filter-${category}`}
                  onClick={() => setSelectedGalleryCategory(category)}
                  className={`px-4 py-2 rounded-full text-xs font-semibold uppercase tracking-wider transition-all duration-200 cursor-pointer ${
                    selectedGalleryCategory === category
                      ? 'bg-amber-500 text-stone-950 shadow-md'
                      : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          {/* Gallery Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6" id="gallery-grid">
            {GALLERY_ITEMS.filter(item => selectedGalleryCategory === 'all' || item.category === selectedGalleryCategory).map((item) => (
              <div
                key={item.id}
                id={`gallery-item-${item.id}`}
                onClick={() => setActiveLightbox(item.image)}
                className="relative h-64 rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 group cursor-pointer border border-stone-200"
              >
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity"></div>
                
                <div className="absolute inset-0 flex flex-col justify-end p-5">
                  <span className="text-amber-400 text-[10px] font-bold uppercase tracking-widest block mb-1">
                    {item.category}
                  </span>
                  <h3 className="text-white font-display font-bold text-sm tracking-wide leading-snug">
                    {item.title}
                  </h3>
                  <div className="text-stone-300 text-[10px] flex items-center mt-2 transform translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                    <span>Click to view large</span>
                    <ExternalLink size={10} className="ml-1" />
                  </div>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* Lightbox Modal */}
      {activeLightbox && (
        <div 
          id="gallery-lightbox"
          onClick={() => setActiveLightbox(null)}
          className="fixed inset-0 bg-black/95 z-50 flex items-center justify-center p-4 backdrop-blur-md cursor-zoom-out"
        >
          <button 
            id="close-lightbox-btn"
            onClick={() => setActiveLightbox(null)}
            className="absolute top-6 right-6 text-white hover:text-amber-400 bg-neutral-900/50 p-3 rounded-full hover:scale-105 transition-all focus:outline-none"
          >
            <X size={28} />
          </button>
          
          <img
            src={activeLightbox}
            alt="Enlarged"
            className="max-h-[85vh] max-w-full object-contain rounded-lg shadow-2xl animate-fade-in"
          />
        </div>
      )}

      {/* 9. Nearby Attractions / Sacred Proximity Guide */}
      <section className="py-24 bg-stone-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Column: List of proximity distances */}
            <div className="lg:col-span-6 space-y-6" id="attractions-guide">
              <span className="text-amber-600 text-xs font-bold uppercase tracking-widest block mb-2">Prime Proximity</span>
              <h2 className="font-display font-black text-4xl text-stone-900 uppercase tracking-tight">
                Heart of Sacred Ayodhya
              </h2>
              <p className="text-stone-600 text-sm leading-relaxed">
                Skip the long traffic routes. Staying at <strong className="text-stone-900">Hotel Raj Darbar Ayodhya</strong> puts you right in the center of key spiritual sites, so you can witness the morning rituals, historical sites, and grand worship ceremonies hassle-free.
              </p>

              <div className="space-y-4 pt-4">
                
                {/* Attr 1 */}
                <div className="bg-white rounded-xl p-4 shadow-sm border border-stone-200/50 flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
                      <MapPin size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-stone-900 text-sm">Shri Ram Janmabhoomi Temple</h4>
                      <p className="text-stone-500 text-xs">The sacred birthplace and historical focal point.</p>
                    </div>
                  </div>
                  <span className="bg-green-100 text-green-800 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase shrink-0">
                    5 Mins Away
                  </span>
                </div>

                {/* Attr 2 */}
                <div className="bg-white rounded-xl p-4 shadow-sm border border-stone-200/50 flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
                      <MapPin size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-stone-900 text-sm">Ram Ki Paidi (Sarayu Ghats)</h4>
                      <p className="text-stone-500 text-xs">Witness the spectacular evening Sarayu Aarti.</p>
                    </div>
                  </div>
                  <span className="bg-green-100 text-green-800 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase shrink-0">
                    3 Mins Away
                  </span>
                </div>

                {/* Attr 3 */}
                <div className="bg-white rounded-xl p-4 shadow-sm border border-stone-200/50 flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
                      <MapPin size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-stone-900 text-sm">Hanuman Garhi Mandir</h4>
                      <p className="text-stone-500 text-xs">Historically grand high-elevation temple fortress.</p>
                    </div>
                  </div>
                  <span className="bg-green-100 text-green-800 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase shrink-0">
                    7 Mins Away
                  </span>
                </div>

                {/* Attr 4 */}
                <div className="bg-white rounded-xl p-4 shadow-sm border border-stone-200/50 flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
                      <MapPin size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-stone-900 text-sm">Kanak Bhawan</h4>
                      <p className="text-stone-500 text-xs">Stunning golden palace temple architecture.</p>
                    </div>
                  </div>
                  <span className="bg-green-100 text-green-800 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase shrink-0">
                    8 Mins Away
                  </span>
                </div>

                {/* Attr 5 */}
                <div className="bg-white rounded-xl p-4 shadow-sm border border-stone-200/50 flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
                      <Building size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-stone-900 text-sm">Ayodhya Dham Railway Station</h4>
                      <p className="text-stone-500 text-xs">Ultra-modern railway terminal building.</p>
                    </div>
                  </div>
                  <span className="bg-green-100 text-green-800 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase shrink-0">
                    10 Mins Away
                  </span>
                </div>

              </div>

            </div>

            {/* Right Column: Google Maps Frame */}
            <div className="lg:col-span-6">
              <div className="bg-white p-4 rounded-2xl shadow-xl border border-stone-200/80">
                <div className="rounded-xl overflow-hidden h-[400px] relative">
                  <iframe
                    src={HOTEL_INFO.mapIframeUrl}
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen={true}
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    title="Hotel Raj Darbar Map Location"
                    className="absolute inset-0"
                  ></iframe>
                </div>
                <div className="p-4 pt-5 bg-stone-50 rounded-xl mt-4 border border-stone-100 text-xs text-stone-600 flex items-start space-x-3">
                  <MapPin size={18} className="text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-stone-800 block mb-1 uppercase tracking-wide">Our Official Location Address</span>
                    <p>{HOTEL_INFO.address}</p>
                  </div>
                </div>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* 10. Reviews & Testimonials Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-amber-600 text-xs font-bold uppercase tracking-widest block mb-2">Guest Gratitude</span>
            <h2 className="font-display font-extrabold text-stone-900 text-3xl sm:text-4xl uppercase tracking-tight">
              Loved By Pilgrims
            </h2>
            <div className="h-0.5 w-16 bg-amber-500 mx-auto mt-4 mb-6"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8" id="testimonials-list">
            {TESTIMONIALS.map((t) => (
              <div 
                key={t.id}
                id={`testimonial-card-${t.id}`}
                className="bg-[#FAF9F5] border border-stone-200 rounded-2xl p-8 flex flex-col justify-between shadow-sm hover:shadow-md transition-all duration-300"
              >
                <div>
                  {/* Stars */}
                  <div className="flex space-x-1 mb-4 text-amber-500">
                    {[...Array(t.rating)].map((_, i) => (
                      <Star key={i} size={16} fill="currentColor" />
                    ))}
                  </div>

                  {/* Review Text */}
                  <p className="text-stone-700 text-sm leading-relaxed italic mb-6">
                    "{t.review}"
                  </p>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-stone-200/60 mt-4 text-xs">
                  <div>
                    <span className="font-bold text-stone-900 block">{t.name}</span>
                    <span className="text-stone-500">{t.location}</span>
                  </div>
                  <span className="text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full font-semibold uppercase text-[9px] tracking-wider">
                    {t.date}
                  </span>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* 11. FAQ Section */}
      <section className="py-20 bg-stone-50">
        <div className="max-w-4xl mx-auto px-4">
          
          <div className="text-center mb-16">
            <h2 className="font-display font-extrabold text-stone-900 text-3xl uppercase tracking-tight">
              Frequently Asked Questions
            </h2>
            <div className="h-0.5 w-16 bg-amber-500 mx-auto mt-4"></div>
          </div>

          <div className="space-y-4" id="faq-accordion">
            
            <div className="bg-white rounded-xl p-6 border border-stone-200 shadow-sm">
              <h4 className="font-bold text-stone-900 text-md mb-2">Is the hotel close to Ram Janmabhoomi Mandir?</h4>
              <p className="text-stone-600 text-xs sm:text-sm leading-relaxed">
                Yes! We are located in the primary visitor zone of Ayodhya, approximately 5 minutes away from the main Ram Janmabhoomi Temple entrance gates.
              </p>
            </div>

            <div className="bg-white rounded-xl p-6 border border-stone-200 shadow-sm">
              <h4 className="font-bold text-stone-900 text-md mb-2">Is the restaurant inside the hotel 100% vegetarian?</h4>
              <p className="text-stone-600 text-xs sm:text-sm leading-relaxed">
                Yes, absolutely. La'Pulse Dine is a strictly 100% pure vegetarian (and optionally Satvik) multi-cuisine restaurant. No meat, seafood, or alcohol is served or allowed within the hotel premises to honor the sacred surroundings.
              </p>
            </div>

            <div className="bg-white rounded-xl p-6 border border-stone-200 shadow-sm">
              <h4 className="font-bold text-stone-900 text-md mb-2">Do you provide temple tour packages and guides?</h4>
              <p className="text-stone-600 text-xs sm:text-sm leading-relaxed">
                Yes. Our dedicated in-house spiritual travel desk helps guests with VIP Darshan ticketing, morning/evening Sarayu Aarti boat rides, expert tour guides, and secure cab arrangements.
              </p>
            </div>

            <div className="bg-white rounded-xl p-6 border border-stone-200 shadow-sm">
              <h4 className="font-bold text-stone-900 text-md mb-2">What is your cancellation policy?</h4>
              <p className="text-stone-600 text-xs sm:text-sm leading-relaxed">
                We offer free cancellation up to 48 hours prior to your scheduled check-in date. Cancellations made within 48 hours are subject to a one-night room tariff charge.
              </p>
            </div>

          </div>

        </div>
      </section>

      {/* 12. Contact Form & Fast Info Section */}
      <section id="contact" className="py-24 bg-white border-t border-stone-200 scroll-mt-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            
            {/* Left Column: Direct Info */}
            <div className="lg:col-span-5 space-y-8" id="contact-info-panel">
              <div>
                <span className="text-amber-600 text-xs font-bold uppercase tracking-widest block mb-2">Connect With Us</span>
                <h2 className="font-display font-black text-4xl text-stone-900 uppercase tracking-tight">
                  Get In Touch
                </h2>
                <p className="text-stone-500 text-sm mt-3">
                  Have questions about room reservations, customized banquet events, block family bookings, or special satvik catering? Reach out directly and our staff will respond instantly.
                </p>
              </div>

              <div className="space-y-6">
                
                {/* Info 1 */}
                <div className="flex items-start">
                  <div className="w-11 h-11 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 mr-4 shrink-0 mt-0.5">
                    <Phone size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold text-stone-900 text-xs uppercase tracking-wider mb-1">Reservation Hotlines</h4>
                    <p className="text-stone-700 text-sm font-semibold">{HOTEL_INFO.phone1}</p>
                    <p className="text-stone-700 text-sm font-semibold">{HOTEL_INFO.phone2}</p>
                    <p className="text-stone-600 text-xs">Helpdesk lines open 24/7</p>
                  </div>
                </div>

                {/* Info 2 */}
                <div className="flex items-start">
                  <div className="w-11 h-11 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 mr-4 shrink-0 mt-0.5">
                    <Mail size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold text-stone-900 text-xs uppercase tracking-wider mb-1">Email Correspondence</h4>
                    <p className="text-stone-700 text-sm font-semibold">{HOTEL_INFO.email}</p>
                    <p className="text-stone-600 text-xs">Direct response in under 2 hours</p>
                  </div>
                </div>

                {/* Info 3 */}
                <div className="flex items-start">
                  <div className="w-11 h-11 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 mr-4 shrink-0 mt-0.5">
                    <MapPin size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold text-stone-900 text-xs uppercase tracking-wider mb-1">Hotel Landmark Address</h4>
                    <p className="text-stone-700 text-xs leading-relaxed">{HOTEL_INFO.address}</p>
                  </div>
                </div>

              </div>

              {/* Secure Booking Guarantee Box */}
              <div className="bg-amber-50 border border-amber-200/60 p-6 rounded-2xl flex items-start space-x-4">
                <ShieldCheck size={28} className="text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-amber-900 text-sm uppercase tracking-wide">Direct Booking Guarantee</h4>
                  <p className="text-stone-600 text-xs leading-relaxed mt-1">
                    Book directly through our official hotlines or online portal to receive complimentary morning temple Prasad, early morning breakfast, and flexible checkout timings.
                  </p>
                </div>
              </div>

            </div>

            {/* Right Column: Interactive Form */}
            <div className="lg:col-span-7">
              <div className="bg-white border border-stone-200 p-8 rounded-2xl shadow-xl">
                
                <h3 className="font-display font-bold text-2xl text-stone-900 uppercase tracking-wide mb-6">
                  Send A Message
                </h3>

                {contactSuccess ? (
                  <div className="bg-green-50 border border-green-200 rounded-xl p-6 text-green-800 text-center space-y-3 animate-fade-in">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center text-green-600 mx-auto">
                      <Check size={24} />
                    </div>
                    <h4 className="font-bold text-lg">Thank You So Much!</h4>
                    <p className="text-xs sm:text-sm">
                      Your message has been sent successfully to the Hotel Raj Darbar reception desk. Our customer relationship team will call you back shortly.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleContactSubmit} className="space-y-4" id="contact-form">
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-stone-600 text-xs font-semibold mb-1">Full Name</label>
                        <input
                          type="text"
                          required
                          value={contactForm.name}
                          onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                          placeholder="Lord Rama Devotee"
                          className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2.5 px-3.5 text-sm text-stone-900 focus:outline-none focus:border-amber-500 transition-colors placeholder:text-stone-400"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-stone-600 text-xs font-semibold mb-1">Phone Number</label>
                        <input
                          type="tel"
                          required
                          value={contactForm.phone}
                          onChange={(e) => setContactForm({ ...contactForm, phone: e.target.value })}
                          placeholder="+91 98765 43210"
                          className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2.5 px-3.5 text-sm text-stone-900 focus:outline-none focus:border-amber-500 transition-colors placeholder:text-stone-400"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-stone-600 text-xs font-semibold mb-1">Email Address</label>
                      <input
                        type="email"
                        required
                        value={contactForm.email}
                        onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                        placeholder="yourname@gmail.com"
                        className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2.5 px-3.5 text-sm text-stone-900 focus:outline-none focus:border-amber-500 transition-colors placeholder:text-stone-400"
                      />
                    </div>

                    <div>
                      <label className="block text-stone-600 text-xs font-semibold mb-1">Subject</label>
                      <input
                        type="text"
                        required
                        value={contactForm.subject}
                        onChange={(e) => setContactForm({ ...contactForm, subject: e.target.value })}
                        placeholder="Family Room Booking / Banquet Inquiry"
                        className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2.5 px-3.5 text-sm text-stone-900 focus:outline-none focus:border-amber-500 transition-colors placeholder:text-stone-400"
                      />
                    </div>

                    <div>
                      <label className="block text-stone-600 text-xs font-semibold mb-1">Message Detail</label>
                      <textarea
                        rows={4}
                        required
                        value={contactForm.message}
                        onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                        placeholder="Kindly describe your query or reservation dates..."
                        className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2.5 px-3.5 text-sm text-stone-900 focus:outline-none focus:border-amber-500 transition-colors placeholder:text-stone-400"
                      ></textarea>
                    </div>

                    <button
                      id="contact-submit-btn"
                      type="submit"
                      className="w-full bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold py-3 px-6 rounded-lg text-xs uppercase tracking-wider transition-colors duration-300 flex items-center justify-center space-x-2 cursor-pointer"
                    >
                      <Send size={14} />
                      <span>Send Direct Inquiry</span>
                    </button>

                  </form>
                )}

              </div>
            </div>

          </div>

        </div>
      </section>
        </>
      ) : currentView === 'rooms' ? (
        <RoomsPage 
          rooms={ROOMS} 
          filter={roomsFilter} 
          onFilterChange={setRoomsFilter} 
          onBook={openBookingModal} 
        />
      ) : currentView === 'about' ? (
        <AboutPage 
          onBook={() => openBookingModal()} 
        />
      ) : currentView === 'dining' ? (
        <DiningPage 
          onBackToHome={() => handleNavClick('home')}
        />
      ) : currentView === 'services' ? (
        <ServicesPage 
          onBook={() => openBookingModal()}
          onBackToHome={() => handleNavClick('home')}
        />
      ) : (
        <ContactPage 
          onBackToHome={() => handleNavClick('home')}
        />
      )}

      {/* 13. Footer Section */}
      <footer className="bg-neutral-950 text-stone-400 pt-16 pb-8 border-t border-amber-900/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-12 pb-12 border-b border-neutral-900">
          
          {/* Logo Column */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3 cursor-pointer" onClick={() => scrollToSection('home')}>
              <div className="w-10 h-10 rounded-full border border-amber-500 flex items-center justify-center bg-neutral-900">
                <span className="font-display font-bold text-amber-500 text-sm">RD</span>
              </div>
              <div className="flex flex-col">
                <span className="font-display font-extrabold text-amber-400 text-md tracking-wider leading-none uppercase">
                  Raj Darbar
                </span>
                <span className="text-[8px] text-stone-400 uppercase tracking-widest mt-1">
                  Hotel & Restaurant
                </span>
              </div>
            </div>
            <p className="text-xs leading-relaxed text-stone-500 pt-2">
              Providing modern royal comfort, peace, and luxury behind the multi-level parking near Ayodhya Dham Railway Station.
            </p>
          </div>

          {/* Quick links */}
          <div>
            <h4 className="font-display font-bold text-white text-xs uppercase tracking-widest mb-4">Quick Links</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => handleNavClick('home')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Home Overview
                </button>
              </li>
              <li>
                <button onClick={() => handleNavClick('rooms')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Luxury Rooms
                </button>
              </li>
              <li>
                <button onClick={() => handleNavClick('about')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Heritage About
                </button>
              </li>
              <li>
                <button onClick={() => handleNavClick('services')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Guest Amenities
                </button>
              </li>
              <li>
                <button onClick={() => handleNavClick('dining')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  La'Pulse Fine Dining
                </button>
              </li>
              <li>
                <button onClick={() => handleNavClick('contact')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Contact Us
                </button>
              </li>
            </ul>
          </div>

          {/* Our Brand hotels */}
          <div>
            <h4 className="font-display font-bold text-white text-xs uppercase tracking-widest mb-4">Our Brand Entities</h4>
            <ul className="space-y-2 text-xs text-stone-500">
              <li className="flex items-center space-x-2">
                <Building size={12} className="text-amber-500/60" />
                <span className="text-amber-400">Hotel Raj Darbar (Ayodhya Dham)</span>
              </li>
              <li className="flex items-center space-x-2">
                <Building size={12} className="text-amber-500/60" />
                <span>Raj Darbar Restaurant & Banquet</span>
              </li>
              <li className="flex items-center space-x-2">
                <Building size={12} className="text-amber-500/60" />
                <span>Raj Darbar Luxury Residency</span>
              </li>
            </ul>
          </div>

          {/* Location Info */}
          <div>
            <h4 className="font-display font-bold text-white text-xs uppercase tracking-widest mb-4">Headquarters</h4>
            <p className="text-xs text-stone-500 leading-relaxed mb-4">
              {HOTEL_INFO.address}
            </p>
            <div className="flex space-x-2">
              <a 
                href={`tel:${HOTEL_INFO.phone1}`}
                className="w-8 h-8 rounded-full bg-neutral-900 border border-neutral-800 hover:border-amber-500 hover:text-amber-500 flex items-center justify-center transition-all text-xs"
                title="Call Reservation 1"
              >
                <Phone size={12} />
              </a>
              <a 
                href={`mailto:${HOTEL_INFO.email}`}
                className="w-8 h-8 rounded-full bg-neutral-900 border border-neutral-800 hover:border-amber-500 hover:text-amber-500 flex items-center justify-center transition-all text-xs"
                title="Send Email"
              >
                <Mail size={12} />
              </a>
            </div>
          </div>

        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 flex flex-col md:flex-row items-center justify-between text-[11px] text-stone-600">
          <p>© 2026 Hotel Raj Darbar Ayodhya. All rights reserved.</p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <span className="hover:text-stone-400 cursor-pointer">Privacy Policy</span>
            <span>•</span>
            <span className="hover:text-stone-400 cursor-pointer">Terms & Conditions</span>
            <span>•</span>
            <span className="hover:text-stone-400 cursor-pointer">Sitemap</span>
          </div>
        </div>
      </footer>

      {/* 14. Floating WhatsApp Reservation Widget */}
      <a
        id="whatsapp-widget"
        href={`https://wa.me/919519102222?text=Hello!+I+am+interested+in+booking+a+room+at+Hotel+Raj+Darbar+Ayodhya.`}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-40 bg-[#25D366] hover:bg-[#20ba5a] text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-transform duration-300 flex items-center justify-center border border-white/20"
        title="Chat on WhatsApp"
      >
        <svg
          className="w-6 h-6 fill-current"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.724-1.457L0 24zm6.59-4.846c1.6.95 3.188 1.449 4.625 1.451 5.403.002 9.803-4.381 9.805-9.768.002-2.607-1.012-5.059-2.859-6.908C16.371 2.08 13.924 1.066 11.32 1.065 5.923 1.065 1.52 5.447 1.517 10.835c-.001 1.516.4 2.99 1.159 4.298l-.423 1.545 1.586-.416c1.192.651 2.5 1.036 3.828 1.037z" />
        </svg>
      </a>

      {/* 15. Real-Time Booking / Check Availability Modal */}
      {isBookingModalOpen && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          
          <div className="bg-white border border-stone-200 w-full max-w-2xl rounded-2xl overflow-hidden shadow-2xl relative animate-scale-up" id="booking-modal-content">
            
            {/* Header */}
            <div className="bg-neutral-950 px-6 py-5 flex items-center justify-between border-b border-amber-900/20">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full border border-amber-500/70 flex items-center justify-center">
                  <span className="font-display font-bold text-amber-500 text-xs">RD</span>
                </div>
                <div>
                  <h3 className="font-display font-extrabold text-amber-400 text-sm sm:text-md uppercase tracking-wider leading-none">
                    Hotel Raj Darbar
                  </h3>
                  <span className="text-[9px] text-stone-400 uppercase tracking-widest mt-1 block">
                    Direct Booking Portal
                  </span>
                </div>
              </div>
              
              <button 
                id="close-booking-modal"
                onClick={() => { setIsBookingModalOpen(false); setBookingSuccess(false); }}
                className="text-stone-400 hover:text-white p-1 rounded-full hover:bg-neutral-900 focus:outline-none transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Content Area */}
            <div className="p-6 max-h-[75vh] overflow-y-auto">
              
              {bookingSuccess && confirmedBookingDetails ? (
                // BOOKING CONFIRMATION VOUCHER
                <div className="space-y-6" id="booking-confirmation-voucher">
                  
                  <div className="bg-green-50 border border-green-200 rounded-xl p-5 text-center text-green-800 space-y-1 animate-fade-in">
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-600 mx-auto mb-2">
                      <Check size={20} />
                    </div>
                    <h4 className="font-bold text-lg">Reservation Confirmed!</h4>
                    <p className="text-xs">Your room has been temporarily locked in. Welcome to Ayodhya!</p>
                  </div>

                  {/* Voucher Card */}
                  <div className="bg-[#FAF9F5] border border-stone-300 rounded-xl overflow-hidden shadow-md">
                    
                    {/* Voucher Header */}
                    <div className="bg-neutral-900 px-5 py-4 border-b border-stone-800 text-white flex items-center justify-between">
                      <div className="flex flex-col">
                        <span className="font-display font-bold text-amber-400 text-xs sm:text-sm tracking-wider uppercase">Direct Stay Voucher</span>
                        <span className="text-[10px] text-stone-400 mt-0.5">Please show this voucher during check-in</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[9px] text-stone-400 uppercase block">Reservation ID</span>
                        <span className="font-mono font-bold text-sm text-white">{confirmedBookingDetails.bookingId}</span>
                      </div>
                    </div>

                    {/* Voucher Content */}
                    <div className="p-5 space-y-4 text-xs">
                      
                      <div className="grid grid-cols-2 gap-4 pb-4 border-b border-stone-200">
                        <div>
                          <span className="text-stone-500 font-semibold block uppercase tracking-wide text-[9px] mb-0.5">Guest Name</span>
                          <span className="text-stone-900 font-bold text-sm">{confirmedBookingDetails.customerName}</span>
                        </div>
                        <div>
                          <span className="text-stone-500 font-semibold block uppercase tracking-wide text-[9px] mb-0.5">Contact Number</span>
                          <span className="text-stone-900 font-bold text-sm">{confirmedBookingDetails.customerPhone}</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pb-4 border-b border-stone-200">
                        <div>
                          <span className="text-stone-500 font-semibold block uppercase tracking-wide text-[9px] mb-0.5">Check In</span>
                          <span className="text-stone-900 font-bold">{confirmedBookingDetails.checkIn}</span>
                        </div>
                        <div>
                          <span className="text-stone-500 font-semibold block uppercase tracking-wide text-[9px] mb-0.5">Check Out</span>
                          <span className="text-stone-900 font-bold">{confirmedBookingDetails.checkOut}</span>
                        </div>
                        <div>
                          <span className="text-stone-500 font-semibold block uppercase tracking-wide text-[9px] mb-0.5">Nights Count</span>
                          <span className="text-stone-900 font-bold">{confirmedBookingDetails.days} Night(s)</span>
                        </div>
                        <div>
                          <span className="text-stone-500 font-semibold block uppercase tracking-wide text-[9px] mb-0.5">Total Guests</span>
                          <span className="text-stone-900 font-bold">{confirmedBookingDetails.guests} Guest(s)</span>
                        </div>
                      </div>

                      <div className="pb-4 border-b border-stone-200">
                        <span className="text-stone-500 font-semibold block uppercase tracking-wide text-[9px] mb-1">Selected Room Package</span>
                        <div className="flex items-center justify-between bg-white p-3 rounded-lg border border-stone-200">
                          <span className="font-bold text-stone-900">{confirmedBookingDetails.roomName}</span>
                          <span className="text-stone-600 font-medium">₹{confirmedBookingDetails.roomPrice.toLocaleString()} / Night</span>
                        </div>
                      </div>

                      {/* Financials details invoice */}
                      <div className="space-y-1.5 pt-2">
                        <span className="text-stone-500 font-semibold block uppercase tracking-wide text-[9px] mb-2">Cost Breakdown Details</span>
                        <div className="flex justify-between text-stone-600">
                          <span>Stay Fare ({confirmedBookingDetails.days} Night x ₹{confirmedBookingDetails.roomPrice.toLocaleString()})</span>
                          <span>₹{confirmedBookingDetails.basePrice.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-stone-600">
                          <span>Statutory Luxury GST (12%)</span>
                          <span>₹{confirmedBookingDetails.tax.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-stone-600">
                          <span>Service & Processing Charges</span>
                          <span>₹{confirmedBookingDetails.serviceCharge.toLocaleString()}</span>
                        </div>
                        <div className="h-0.5 w-full bg-stone-300 my-2"></div>
                        <div className="flex justify-between font-bold text-stone-900 text-sm">
                          <span>Total Amount Pay-At-Hotel</span>
                          <span className="text-amber-800 font-display">₹{confirmedBookingDetails.totalPrice.toLocaleString()}</span>
                        </div>
                      </div>

                      {confirmedBookingDetails.specialRequests && (
                        <div className="bg-amber-50 p-3 rounded-lg border border-amber-200/50 mt-4 text-stone-600 text-[11px]">
                          <span className="font-bold text-amber-900 block mb-1">Special Requests Notes:</span>
                          "{confirmedBookingDetails.specialRequests}"
                        </div>
                      )}

                    </div>

                    {/* Voucher Footer */}
                    <div className="bg-amber-100 px-5 py-3 border-t border-stone-300 text-amber-900 flex items-center justify-between text-[11px] font-semibold">
                      <span className="flex items-center">
                        <Gift size={14} className="mr-1 shrink-0" />
                        Free Morning Prasad included with stays!
                      </span>
                      <span>No prepayment required</span>
                    </div>

                  </div>

                  {/* Actions */}
                  <div className="flex space-x-3 pt-4">
                    <button
                      id="print-invoice-btn"
                      onClick={() => window.print()}
                      className="flex-1 bg-stone-900 hover:bg-stone-800 text-white font-bold py-3 rounded-lg text-xs uppercase tracking-wider text-center cursor-pointer"
                    >
                      Printstay Invoice
                    </button>
                    <button
                      id="done-booking-btn"
                      onClick={() => { setIsBookingModalOpen(false); setBookingSuccess(false); }}
                      className="flex-1 bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold py-3 rounded-lg text-xs uppercase tracking-wider text-center cursor-pointer"
                    >
                      Done, Thank You!
                    </button>
                  </div>

                </div>
              ) : (
                // STAY BOOKING FORM
                <form onSubmit={handleBookingSubmit} className="space-y-6" id="stay-booking-form">
                  
                  {/* Select Room type dropdown inside form */}
                  <div>
                    <label className="block text-stone-700 text-xs font-bold uppercase tracking-wider mb-2">
                      1. Select Your Stay Sanctuary
                    </label>
                    <select
                      value={selectedRoomType === 'all' ? 'deluxe' : selectedRoomType}
                      onChange={(e) => setSelectedRoomType(e.target.value)}
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-3 px-3.5 text-sm text-stone-900 focus:outline-none focus:border-amber-500 font-semibold"
                    >
                      {ROOMS.map((room) => (
                        <option key={room.id} value={room.id}>
                          {room.name} — ₹{room.price.toLocaleString()} / Night
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Stay timings selectors */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-stone-700 text-xs font-bold uppercase tracking-wider mb-2">Check In</label>
                      <input
                        type="date"
                        required
                        value={checkIn}
                        onChange={(e) => setCheckIn(e.target.value)}
                        className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2.5 px-3.5 text-sm font-medium"
                      />
                    </div>
                    <div>
                      <label className="block text-stone-700 text-xs font-bold uppercase tracking-wider mb-2">Check Out</label>
                      <input
                        type="date"
                        required
                        value={checkOut}
                        onChange={(e) => setCheckOut(e.target.value)}
                        className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2.5 px-3.5 text-sm font-medium"
                      />
                    </div>
                    <div>
                      <label className="block text-stone-700 text-xs font-bold uppercase tracking-wider mb-2">Rooms / Guests</label>
                      <select
                        value={guestsCount}
                        onChange={(e) => setGuestsCount(e.target.value)}
                        className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2.5 px-3.5 text-sm text-stone-900 font-medium"
                      >
                        <option value="1">1 Guest</option>
                        <option value="2">2 Guests</option>
                        <option value="3">3 Guests</option>
                        <option value="4">4 Guests</option>
                        <option value="5">5+ Guests (Family)</option>
                      </select>
                    </div>
                  </div>

                  {/* Guest details section */}
                  <div className="space-y-4 pt-4 border-t border-stone-100">
                    <label className="block text-stone-700 text-xs font-bold uppercase tracking-wider">
                      2. Guest Contact Information
                    </label>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-stone-600 text-[11px] mb-1">Full Name</label>
                        <input
                          type="text"
                          required
                          value={bookingForm.name}
                          onChange={(e) => setBookingForm({ ...bookingForm, name: e.target.value })}
                          placeholder="Your Name (matching Aadhaar/ID)"
                          className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2.5 px-3.5 text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-stone-600 text-[11px] mb-1">Phone Number</label>
                        <input
                          type="tel"
                          required
                          value={bookingForm.phone}
                          onChange={(e) => setBookingForm({ ...bookingForm, phone: e.target.value })}
                          placeholder="+91 98765 43210"
                          className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2.5 px-3.5 text-sm"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-stone-600 text-[11px] mb-1">Email Address</label>
                      <input
                        type="email"
                        required
                        value={bookingForm.email}
                        onChange={(e) => setBookingForm({ ...bookingForm, email: e.target.value })}
                        placeholder="yourname@gmail.com"
                        className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2.5 px-3.5 text-sm"
                      />
                    </div>

                    <div>
                      <label className="block text-stone-600 text-[11px] mb-1">Special Stay Requests (Optional)</label>
                      <textarea
                        rows={2}
                        value={bookingForm.specialRequests}
                        onChange={(e) => setBookingForm({ ...bookingForm, specialRequests: e.target.value })}
                        placeholder="E.g. Ground floor room preferred, early check-in, satvik baby food, fast track darshan ticketing..."
                        className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2.5 px-3.5 text-sm placeholder:text-stone-400"
                      ></textarea>
                    </div>

                  </div>

                  {/* Submit staying reservation direct */}
                  <div className="pt-4">
                    <button
                      id="confirm-booking-btn"
                      type="submit"
                      className="w-full bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold py-3 px-6 rounded-lg text-sm uppercase tracking-wider text-center cursor-pointer transition-colors"
                    >
                      Confirm Free Stay Booking
                    </button>
                    <p className="text-[10px] text-stone-500 text-center mt-2.5">
                      No charge today! You will pay directly in cash or card at the front desk when checking in.
                    </p>
                  </div>

                </form>
              )}

            </div>

          </div>

        </div>
      )}

    </div>
  );
}
